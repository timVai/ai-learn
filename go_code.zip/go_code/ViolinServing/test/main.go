package test

//
///*
//#cgo CFLAGS: -I ../../include
//#cgo LDFLAGS: -L ../../lib -llibhello
//#include "hello.h"
//*/
//import "C"
//
//func main() {
//
//	C.output()
//
//}
