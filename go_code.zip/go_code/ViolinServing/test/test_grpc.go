package test

import (
	"ViolinServing/api/proto/service"
	"context"
	"fmt"
	"google.golang.org/grpc"
	"log"
)

func TestGrpc() {
	fmt.Println("testGrpc")
	conn, err := grpc.Dial("localhost:8081", grpc.WithInsecure())
	if err != nil {
		log.Fatal("did not connect: %v", err)
	}
	defer conn.Close()
	client := violinservice.NewViolinServiceClient(conn)

	request := violinservice.Request{}
	request.Name = "a*b"
	request.Type = violinservice.ModelType_TENSORFLOW
	request.Version = "1"

	input := violinservice.Tensor{}
	input.TensorName = "a"
	input.TensorType = violinservice.DType_float32
	input.TensorValue = []float64{33}

	input2 := violinservice.Tensor{}
	input2.TensorName = "b"
	input2.TensorType = violinservice.DType_float32
	input2.TensorValue = []float64{50}

	request.Inputs = append(request.Inputs, &input)
	request.Inputs = append(request.Inputs, &input2)

	request.OutputNames = []string{"c"}

	rsp, err := client.Predict(context.Background(), &request)
	if err != nil {
		log.Fatal("could not greet: %v", err)
	}
	log.Println("response : %s", rsp.RspCode)
	log.Print(rsp)

}

//
//func TestGrpc2() {
//	fmt.Println("testGrpc2")
//	conn, err := grpc.Dial("localhost:8081", grpc.WithInsecure())
//	if err != nil {
//		log.Fatal("did not connect: %v", err)
//	}
//	defer conn.Close()
//	client := violinservice.NewViolinServiceClient(conn)
//
//	request := violinservice.Request{}
//	request.Name = "modelName1"
//	request.Type = "tensorflow"
//	request.Version = "1"
//
//	input := violinservice.Tensor{}
//	input.TensorName = "word_ids"
//	input.TensorType = "int"
//	input.Dim = append(input.Dim, 1)
//	input.Dim = append(input.Dim, 200)
//	for i := 0; i < 200; i++ {
//		input.TensorValue = append(input.TensorValue, strconv.Itoa(i))
//	}
//
//	input2 := violinservice.Tensor{}
//	input2.TensorName = "sequence_lengths"
//	input2.TensorType = "int"
//	input2.Dim = append(input2.Dim, 1)
//	input2.TensorValue = []string{"200"}
//
//	input3 := violinservice.Tensor{}
//	input3.TensorName = "dropout"
//	input3.TensorType = "float"
//	input3.Dim = append(input3.Dim, 0)
//	input3.TensorValue = []string{"1.0"}
//
//	request.Inputs = append(request.Inputs, &input)
//	request.Inputs = append(request.Inputs, &input2)
//	request.Inputs = append(request.Inputs, &input3)
//
//	request.OutputNames = []string{"loss_op/decode/cond/ReverseSequence_1"}
//
//	rsp, err := client.Predict(context.Background(), &request)
//	if err != nil {
//		log.Fatal("could not greet: %v", err)
//	}
//	log.Print("response code : ", rsp.RspCode)
//	log.Print("response batchId : ", rsp.Ext)
//
//	//log.Println("return data : ", (rsp.Outputs[0]))
//
//}
