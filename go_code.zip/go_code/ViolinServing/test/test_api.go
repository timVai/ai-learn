package test

//
//func GoInvokeLoadModel() {
//	modelInfo := ViolinInner.Model{}
//	modelInfo.Type = "tensorflow"
//	modelInfo.Name = "a*b"
//	modelInfo.Version = "1"
//	modelInfo.Path = "/Users/zhangwenjie10/go_workspace/src/ViolinServing/lib/BilstmCrf_cmtForbid.pb"
//
//
//	rsp := hub.LoadModel(modelInfo)
//
//	fmt.Println(rsp)
//}
//
//
//func GoInvokePredict() {
//	GoInvokeLoadModel()
//
//	innerTensor10 := ViolinInner.InnerTensor{}
//	innerTensor10.TensorType = "int"
//
//
//	input1 := ViolinInner.Input{}
//	input1.InputTensor = append(input1.InputTensor, &innerTensor10)
//
//	input2 := ViolinInner.Input{}
//	input2.TensorName = "b"
//	input2.TensorType = "float"
//	input2.TensorValue = []string{"50"}
//
//	req := ViolinInner.Request{}
//	req.Input = append(req.Input, &input)
//	req.Input = append(req.Input, &input2)
//	req.OutputNames = []string{"c"}
//
//	modelInfo := ViolinInner.Model{}
//	modelInfo.Type = "tensorflow"
//	modelInfo.Name = "a*b"
//	modelInfo.Version = 1
//	req.Model = &modelInfo
//
//	rsp := api.Predict(req)
//
//	fmt.Println(rsp)
//}
//
//func GoInvokeUnLoadModel() {
//	modelInfo := ViolinInner.Model{}
//	modelInfo.Type = "tensorflow"
//	modelInfo.Name = "a*b"
//	modelInfo.Version = 1
//	modelInfo.Path = "/Users/fanfengshi/Desktop/lib/graph.pb"
//
//	req := ViolinInner.Request{}
//	req.Model = &modelInfo
//
//	rsp := api.UnLoadModel(req)
//
//	fmt.Println(rsp)
//}
//
//func TestNewPredict() {
//	model_type := "tensorflow"
//	model_name := "banned"
//	model_version := "1"
//
//	model := ViolinInner.Model{
//		Type:    model_type,
//		Name:    model_name,
//		Path:    "/Users/fanfengshi/Desktop/lib/model/BilstmCrf_cmtForbid.pb",
//		Version: model_version,
//	}
//	/*---------load--------*/
//
//	modelStatus := hub.LoadModel(model)
//	fmt.Print(modelStatus)
//
//	/*---------predict--------*/
//	request := ViolinInner.Request{}
//	request.Model = &model
//	inputTensor := ViolinInner.InnerTensor{}
//	inputTensor.TensorType = "int"
//	inputTensor.TensorName = "word_ids"
//	inputTensor.Dim = append(inputTensor.Dim, 1)
//	inputTensor.Dim = append(inputTensor.Dim, 200)
//	for i := 5; i < 205; i++ {
//		inputTensor.TensorValue = append(inputTensor.TensorValue, strconv.Itoa(i))
//	}
//
//	inputTensor2 := ViolinInner.InnerTensor{}
//	inputTensor2.TensorType = "int"
//	inputTensor2.TensorName = "sequence_lengths"
//	inputTensor2.Dim = append(inputTensor2.Dim, 1)
//	inputTensor2.TensorValue = append(inputTensor2.TensorValue, "200")
//
//	inputTensor3 := ViolinInner.InnerTensor{}
//	inputTensor3.TensorType = "float"
//	inputTensor3.TensorName = "dropout"
//	inputTensor3.Dim = append(inputTensor3.Dim, 0)
//	inputTensor3.TensorValue = append(inputTensor3.TensorValue, "1.0")
//
//	input := ViolinInner.Input{}
//	input.InputTensors = append(input.InputTensors, &inputTensor)
//	input.InputTensors = append(input.InputTensors, &inputTensor2)
//	input.InputTensors = append(input.InputTensors, &inputTensor3)
//
//	input.OutputNames = append(input.OutputNames, "loss_op/decode/cond/ReverseSequence_1")
//
//	request.InputBatch = append(request.InputBatch, &input)
//
//	/////////////////
//	inputTensor11 := ViolinInner.InnerTensor{}
//	inputTensor11.TensorType = "int"
//	inputTensor11.TensorName = "word_ids"
//	inputTensor11.Dim = append(inputTensor11.Dim, 1)
//	inputTensor11.Dim = append(inputTensor11.Dim, 200)
//	for i := 40; i < 240; i++ {
//		inputTensor11.TensorValue = append(inputTensor11.TensorValue, strconv.Itoa(i))
//	}
//
//	inputTensor12 := ViolinInner.InnerTensor{}
//	inputTensor12.TensorType = "int"
//	inputTensor12.TensorName = "sequence_lengths"
//	inputTensor12.Dim = append(inputTensor12.Dim, 1)
//	inputTensor12.TensorValue = append(inputTensor12.TensorValue, "200")
//
//	inputTensor13 := ViolinInner.InnerTensor{}
//	inputTensor13.TensorType = "float"
//	inputTensor13.TensorName = "dropout"
//	inputTensor13.Dim = append(inputTensor13.Dim, 0)
//	inputTensor13.TensorValue = append(inputTensor13.TensorValue, "1.0")
//
//	input1 := ViolinInner.Input{}
//	input1.InputTensors = append(input1.InputTensors, &inputTensor11)
//	input1.InputTensors = append(input1.InputTensors, &inputTensor12)
//	input1.InputTensors = append(input1.InputTensors, &inputTensor13)
//
//	input1.OutputNames = append(input1.OutputNames, "loss_op/decode/cond/ReverseSequence_1")
//
//	request.InputBatch = append(request.InputBatch, &input1)
//
//	//input2 := ViolinInner.Input{}
//	//input2.OutputNames = append(input2.OutputNames, "loss_op/decode/cond/ReverseSequence_1")
//	//request.InputBatch = append(request.InputBatch, &input2)
//
//	response := hub.Predict(request)
//
//	fmt.Println("+================================")
//	fmt.Println(response)
//
//	fmt.Println(response.RspCode)
//	fmt.Println(response.Msg)
//	for i := 0; i < len(response.OutputBatch); i++ {
//		output := response.OutputBatch[i]
//		fmt.Println("outputs", i, strings.Join(output.OutputNames, "@"))
//		for j := 0; j < len(output.OutputTensors); j++ {
//			innerTensor := output.OutputTensors[j]
//			fmt.Println("innerTensor index : ", j)
//			//fmt.Println(innerTensor.TensorName)
//			//fmt.Println(innerTensor.TensorType)
//			fmt.Println(innerTensor.TensorValue)
//			fmt.Println(innerTensor.Dim)
//		}
//	}
//
//	fmt.Println("unload--unload--unload--unload--unload--unload--unload--unload--unload--")
//	fmt.Println(hub.UnLoadModel(model))
//}
//
//func TestPredictMultiOutput() {
//	model_type := "tensorflow"
//	model_name := "emotion"
//	model_version := "1"
//	model_path := "/Users/fanfengshi/Desktop/lib/model/emotion.pb"
//
//	model := ViolinInner.Model{
//		Type:    model_type,
//		Name:    model_name,
//		Path:    model_path,
//		Version: model_version,
//	}
//	/*---------load--------*/
//
//	modelStatus := hub.LoadModel(model)
//	fmt.Print(modelStatus)
//
//	/*---------predict--------*/
//	request := ViolinInner.Request{}
//	request.Model = &model
//	inputTensor := ViolinInner.InnerTensor{}
//	inputTensor.TensorType = "int"
//	inputTensor.TensorName = "input_x"
//	inputTensor.Dim = append(inputTensor.Dim, 1)
//	inputTensor.Dim = append(inputTensor.Dim, 128)
//	for i := 0; i < 128; i++ {
//		inputTensor.TensorValue = append(inputTensor.TensorValue, strconv.Itoa(i))
//	}
//
//	inputTensor2 := ViolinInner.InnerTensor{}
//	inputTensor2.TensorType = "float"
//	inputTensor2.TensorName = "dropout_keep_prob"
//	inputTensor2.Dim = append(inputTensor2.Dim, 0)
//	inputTensor2.TensorValue = append(inputTensor2.TensorValue, "1.0")
//
//	input := ViolinInner.Input{}
//	input.InputTensors = append(input.InputTensors, &inputTensor)
//	input.InputTensors = append(input.InputTensors, &inputTensor2)
//
//	input.OutputNames = append(input.OutputNames, "prob_dist")
//	input.OutputNames = append(input.OutputNames, "predictions")
//
//	request.InputBatch = append(request.InputBatch, &input)
//
//	response := hub.Predict(request)
//
//	fmt.Println("+================================")
//	//fmt.Println(response)
//
//	fmt.Println("response code : ", response.RspCode)
//	fmt.Println("response msg : ", response.Msg)
//	for i := 0; i < len(response.OutputBatch); i++ {
//		output := response.OutputBatch[i]
//		fmt.Println("output names concat : ", i, strings.Join(output.OutputNames, "@"))
//		for j := 0; j < len(output.OutputTensors); j++ {
//			innerTensor := output.OutputTensors[j]
//			fmt.Println("innerTensor index : ", j)
//			fmt.Println("tensor name : ", innerTensor.TensorName)
//			fmt.Println("tensor type : ", innerTensor.TensorType)
//			fmt.Println("tensor value : ", innerTensor.TensorValue)
//			fmt.Println(innerTensor.Dim)
//		}
//	}
//
//	fmt.Println("unload--unload--unload--unload--unload--unload--unload--unload--unload--")
//	fmt.Println(hub.UnLoadModel(model))
//}
