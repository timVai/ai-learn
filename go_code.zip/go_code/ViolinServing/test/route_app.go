package test

func TestRouteApp() {
	//日志记录器
	//route := autobatch.NewRouter(int32(100), time.Microsecond*200)
	//start := time.Now().UnixNano()
	//returnsucNum := int64(0)
	//returnFailNum := int64(0)
	//allCount := 90
	//for i := 1; i <= allCount; i++ {
	//	volinRequest := route.BuildVoilinRequest(ViolinInner.Request{}, false)
	//	//fmt.Printf("start test the call index [%d] \n", i)
	//	route.Dispatch(volinRequest)
	//	go func(index int, request autobatch.ViolinRequest) {
	//		defer func(index int) {
	//			if p := recover(); p != nil {
	//				atomic.AddInt64(&returnFailNum, 1)
	//				fmt.Printf("catch the exception for i:[%d] \n", index)
	//			}
	//		}(i)
	//		//res := request.GetRawRespon(time.Millisecond * 20)
	//		atomic.AddInt64(&returnsucNum, 1)
	//		//fmt.Printf("complete i:[%d] request-seqId:[%d] return-seqId:[%d] \n", index, request.SeqId, res.ID)
	//
	//	}(i, volinRequest)
	//}
	//
	//for {
	//	if returnFailNum+returnsucNum >= int64(allCount) {
	//		end := time.Now().UnixNano()
	//		elapsedTime := (end - start) / (1000 * 1000)
	//		fmt.Printf("all code run cost the times [%d] ms succ:[%d] fail:[%d]\n", elapsedTime, returnsucNum, returnFailNum)
	//		break
	//	}
	//}
}
