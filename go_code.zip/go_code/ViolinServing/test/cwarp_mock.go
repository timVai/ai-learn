package test

//
///*
//#cgo LDFLAGS: -L../lib -lcpptest
//#cgo CFLAGS: -I ../include
//#include "library.h"
//*/
//import "C"
//
////#include <stdlib.h>
//import "C"
//
//import (
//	"fmt"
//)
//
//func TestCgo() {
//	//fmt.Println("Hello, World! begin")
//
//	//C.hello()
//	//fmt.Println(C.add(C.int(0),6))
//
//	//var out = C.uchar('z')
//	//C.tchar(C.uchar('1'),C.int(1),out)
//	//fmt.Println(out)
//
//	//var i1 = C.uchar('a')
//	//var i2 = C.int(1)
//	//var outptr = C.uchar('a')
//	//C.tcharptr(i1, i2,  &outptr )
//	////C.tcharptr(i1, i2, (*C.uchar) (unsafe.Pointer(&outptr)) )
//	//fmt.Println(i1)
//	//fmt.Println(i2)
//	//fmt.Println(outptr)
//
//	//var in = make([]byte, 10)
//	//var outs = make([]byte,10)
//	////C.testchararr(&in , C.int(10) , &outs)   //type error!!!
//	//C.testchararr(((*C.uchar)(unsafe.Pointer(&in[0]))) , C.int(10) , ((*C.uchar)(unsafe.Pointer(&outs[0]))))
//	//fmt.Println(outs)
//
//	//var buf bytes.Buffer
//	//buf.Write([]byte("Hello, cgo!\n"))
//	//slice := buf.Bytes()
//	//C.write(1, unsafe.Pointer(&slice[0]), C.size_t(len(slice)))
//
//	////var in = make([](*C.uchar),10)
//	//in := []byte{0,0,0,0,0,0,0,0,0}
//	////var buf = bytes.NewBuffer([]byte{0,0,0,0})
//	////outb := buf.Bytes()
//	//
//	//var outb *C.uchar = nil
//	//
//	////defer C.free(unsafe.Pointer(outb))
//	//
//	//nob := C.int(0)
//	//
//	//C.predict(((*C.uchar)(unsafe.Pointer(&in[0]))) , C.int(8) , (outb) , nob)
//	//
//	//fmt.Println(outb)
//	//fmt.Println(nob)
//
//	//canon := C.struct_canon{}
//	//in := []byte{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
//	//canon.func_name = C.CString("playb")
//	//canon.inptr = (*C.uchar)(unsafe.Pointer(&in[0]))
//	//canon.ni = C.int(len(in))
//	//result := C.playb(canon)
//	//fmt.Println(result.inptr)
//	//fmt.Println(result.ni)
//	//fmt.Println(C.GoBytes(unsafe.Pointer(result.outptr),result.no))
//	//fmt.Println(result.no)
//
//	//canon := C.struct_canon{}
//	////defer C.free(unsafe.Pointer(&canon))
//	//canon.func_name = C.CString("dopredict")
//	//m := &model.Pbtest{}
//	//m.ModelName = "aaa"
//	//protoin,_ := proto.Marshal(m)
//	//canon.inptr = (*C.uchar)(unsafe.Pointer(&protoin[0]))
//	//canon.ni = C.int(len(protoin))
//
//	//var ppCanon unsafe.Pointer
//	//ppCanon := unsafe.Pointer(&C.struct_canon{})
//	//C.playv(&ppCanon)
//	//ptr := (*C.struct_canon)(ppCanon)
//	//fmt.Println(ptr.no)
//	//rb := C.GoBytes(unsafe.Pointer(ptr.outptr),ptr.no)
//	////fmt.Println(rb)
//	//m := &model.Pbtest{}
//	//m.XXX_Unmarshal(rb)
//	//fmt.Println(m.ModelPath)
//
//	//var pDetectInfo unsafe.Pointer
//	//
//	//C.setStruct(&pDetectInfo)
//	//
//	//ptr := (*C.struct_DetectFaceInfo)(pDetectInfo)
//	//fmt.Println(ptr.id)
//
//	//re := C.play(canon)
//	//fmt.Println(re.no)
//
//	//
//	////result := C.play(canon)
//	////defer C.free(unsafe.Pointer(&result))
//	//fmt.Println(result.no)
//	////fmt.Println(C.GoBytes(unsafe.Pointer(result.outptr),result.no))
//	//
//	//rb := C.GoBytes(unsafe.Pointer(result.outptr),result.no)
//	////fmt.Println(rb)
//	//ret_m := &model.Pbtest{}
//	//ret_m.XXX_Unmarshal(rb)
//	//fmt.Println(ret_m.ModelName)
//
//	for i := 0; i < 8; i++ {
//		go DoGo(i)
//	}
//	holder := make(chan int)
//
//	fmt.Println("Hello, World! end")
//	r := <-holder
//	fmt.Println(r)
//}
//
//func DoGo(goname int) {
//	for i := 0; i < 10; i++ {
//		fmt.Println("########################## = ", goname, i)
//		//GoInvokeCAPI()
//	}
//}
