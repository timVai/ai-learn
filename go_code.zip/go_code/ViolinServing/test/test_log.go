package test

import (
	"ViolinServing/logs"
)

var logger = logs.LOGGING

func TestLog() {
	for i := 0; i < 800000; i++ {
		go logger.Info("i=", i)
		go logger.Info("i=", i)
	}
	//time.Sleep(time.Second*5)
	hold := make(chan int)
	<-hold

}
