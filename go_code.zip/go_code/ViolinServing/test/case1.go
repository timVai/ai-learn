package test

import (
	"ViolinServing/api/proto/service"
	"ViolinServing/utils/parser"
	"context"
	"fmt"
	"google.golang.org/grpc"
	"log"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

var args = map[string]string{}

func IndexCase1() {

	args["cmd"] = "run"
	args["filePath"] = "/export/Data/50w.wid.cmt"
	args["parallelism"] = "4"
	args["sleep"] = "10000"

	if strings.Compare("run", args["cmd"]) == 0 {
		go run()
	}
}

func run() {
	dataFilePath := args["filePath"]
	parallelism, _ := strconv.Atoi(args["parallelism"])
	sleep, _ := strconv.Atoi(args["sleep"])

	FileRequestTest(dataFilePath, parallelism, time.Millisecond*time.Duration(sleep))
}

var totalSendCnt = int64(0)
var totalTransCnt = int64(0)
var tpRecords = make(chan time.Duration, 1000000000) //int64.max will be better
var maxTp time.Duration

func FileRequestTest(filePath string, parallelism int, sleepTime time.Duration) {

	lines, err := parser.ReadLineAsString(filePath)
	if err != nil {
		return
	}

	//5 = 13/2
	groupDataCnt := len(lines) / parallelism

	var groups = map[string][]string{}

	for groupId := 0; groupId < parallelism; groupId++ {
		startIndex := groupId * groupDataCnt
		groups[strconv.Itoa(groupId)] = lines[startIndex : startIndex+groupDataCnt]
	}

	printQpsTp()

	conn, err := grpc.Dial("localhost:8081", grpc.WithInsecure())
	if err != nil {
		log.Fatal("did not connect: %v", err)
	}

	for groupId := 0; groupId < parallelism; groupId++ {
		ctx, _ := context.WithCancel(context.Background())

		go fire(ctx, conn, groups[strconv.Itoa(groupId)], sleepTime)
		fmt.Println("groupId", groupId, "go begin...")

		//time.Sleep(time.Second * 60)
		//cancel()
	}

}

func printQpsTp() {
	ticker := time.NewTicker(time.Second * 1)
	var lastSendCnt int64 = 0
	var lastTransCnt int64 = 0

	go func() {
		for {
			select {
			case <-ticker.C:
				sendCnt := totalSendCnt - lastSendCnt
				lastSendCnt = totalSendCnt

				cnt := totalTransCnt - lastTransCnt
				lastTransCnt = totalTransCnt

				var totalTp time.Duration
				tpRecordsLen := len(tpRecords)
				for i := 0; i < tpRecordsLen; i++ {
					totalTp += <-tpRecords
				}
				avgTp := totalTp / time.Duration(tpRecordsLen+1)

				fmt.Print("   Send : ", sendCnt)
				fmt.Print("\t QPS : ", cnt)
				fmt.Print("\t avg TP : ", avgTp)
				fmt.Println("\t max TP : ", maxTp)
			}
		}

	}()

}

func fire(ctx context.Context, conn *grpc.ClientConn, data []string, sleepTime time.Duration) {

	for rowNum, row := range data {
		start := time.Now()

		atomic.AddInt64(&totalSendCnt, 1)

		bullet(conn, rowNum, row)

		atomic.AddInt64(&totalTransCnt, 1)

		tp := time.Now().Sub(start)
		tpRecords <- tp
		//fmt.Println(tp)
		if tp > maxTp {
			maxTp = tp
		}

		if sleepTime > 0 {
			time.Sleep(sleepTime)
		}
	}
	//ctx.Done()
}

func bullet(conn *grpc.ClientConn, rowNum int, row string) {

	wordIds := strings.Split(row, " ")

	client := violinservice.NewViolinServiceClient(conn)

	request := violinservice.Request{}
	request.Name = "forbid"
	request.Type = violinservice.ModelType_TENSORFLOW
	request.Version = "1"

	input := violinservice.Tensor{}
	input.TensorName = "word_ids"
	input.TensorType = violinservice.DType_int32
	input.Dim = append(input.Dim, 200)
	for i := 0; i < 200; i++ {
		if i < len(wordIds) {
			floatId, _ := strconv.ParseFloat(wordIds[i], 64)
			input.TensorValue = append(input.TensorValue, floatId)
		} else {
			floatId, _ := strconv.ParseFloat(string(i), 64)
			input.TensorValue = append(input.TensorValue, floatId)
		}
	}

	input2 := violinservice.Tensor{}
	input2.TensorName = "sequence_lengths"
	input2.TensorType = violinservice.DType_int32
	//input2.Dim = append(input2.Dim, 1)
	if len(wordIds) >= 200 {
		input2.TensorValue = []float64{float64(200)}
	} else {
		input2.TensorValue = []float64{float64(len(wordIds))}
	}

	request.Inputs = append(request.Inputs, &input)
	request.Inputs = append(request.Inputs, &input2)

	request.OutputNames = []string{"loss_op/decode/cond/ReverseSequence_1"}

	rsp, err := client.Predict(context.Background(), &request)
	if err != nil {
		log.Fatal("could not greet: %v", err)
	}
	//fmt.Print("response code : ", rsp.RspCode , "    ")
	//fmt.Println("response batchId : ", rsp.Ext)

	if rsp.RspCode != 0 || strings.Compare("ok", rsp.Msg) != 0 {
		fmt.Println("response error", rsp)
	}

	//fmt.Println(rsp.Outputs)
}
