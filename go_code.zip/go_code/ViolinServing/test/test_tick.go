package test

//
//func TestTick() {
//
//	tick.Register(time.Millisecond*500, PPrint, "task1")
//
//	tick.Register(time.Second, PPPrint, "task2")
//
//}
//
//func PPrint(a interface{}) {
//	fmt.Println("PPrint", a.(string))
//}
//
//func PPPrint(a interface{}) {
//	fmt.Println("PPPrint", a.(string))
//}
