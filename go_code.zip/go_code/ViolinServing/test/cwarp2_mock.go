package test

//
///*
//#include <stdio.h>
//#include <stdlib.h>
//#include <unistd.h>
//#include <string.h>
//
//#define MAX_FACES_PER_DETECT 64
//
//typedef  struct Point{
//    float x;
//    float y;
//}Point;
//
//typedef struct Rectangle{
//    Point lt;
//    Point rd;
//}Rectangle;
//
//typedef struct DetectFaceInfo{
//    int id;
//    float score;
//    Rectangle pos;
//}DetectFaceInfo;
//
//
//
//void setStruct(void **ppDetectInfo)
//{
//    DetectFaceInfo *pDetectInfo = (DetectFaceInfo *)malloc(sizeof(DetectFaceInfo));
//    memset(pDetectInfo, 0 , sizeof(pDetectInfo));
//    pDetectInfo->id = 100;
//    pDetectInfo->score = 0.98f;
//    pDetectInfo->pos.lt.x = 1;
//    pDetectInfo->pos.lt.y = 1;
//    pDetectInfo->pos.rd.x = 9;
//    pDetectInfo->pos.rd.y = 10;
//
//    fprintf(stdout, "A pDetectInfo address : %p\n", pDetectInfo);
//    *ppDetectInfo = pDetectInfo;
//}
//
//int printStruct(void *pdetectinfo)
//{
//    DetectFaceInfo * pDetectInfo = (DetectFaceInfo *)pdetectinfo;
//    fprintf(stdout, "B pDetectInfo address : %p\n", pDetectInfo);
//
//    fprintf(stdout, "id: %d\n", pDetectInfo->id);
//    fprintf(stdout, "score : %.3lf\n", pDetectInfo->score);
//    fprintf(stdout, "pos.lt.x : %d\n", pDetectInfo->pos.lt.x);
//    fprintf(stdout, "pos.lt.y : %d\n", pDetectInfo->pos.lt.y);
//    fprintf(stdout, "pos.rd.x : %d\n", pDetectInfo->pos.rd.x);
//    fprintf(stdout, "pos.rd.y : %d\n", pDetectInfo->pos.rd.y);
//}
//
//int freeStruct(void *pDetectInfo)
//{
//    fprintf(stdout, "C pDetectInfo address : %p\n", pDetectInfo);
//    free((DetectFaceInfo*)pDetectInfo);
//}
//
//*/
//import "C"
//
//import (
//	"fmt"
//	_ "fmt"
//	_ "reflect"
//	"unsafe"
//)
//
//func main() {
//	var pDetectInfo unsafe.Pointer
//
//	C.setStruct(&pDetectInfo)
//
//	ptr := (*C.struct_DetectFaceInfo)(pDetectInfo)
//	fmt.Println(ptr.id)
//
//
//	//C.printStruct(pDetectInfo)
//	//C.freeStruct(pDetectInfo)
//}
