/*
  @File : test_chan.go
  @Author : zhangwenjie10
  @Date : 2018-12-17
  @Desc:
*/

package test

//
//func TestChan() {
//	route := autobatch.NewRouter(int32(100), 200)
//
//	allCount := 5000
//	for i := 0; i < allCount; i++ {
//
//		go func(i int) {
//			inputbatch := []*ViolinInner.Input{}
//			var tensorValue = []string{}
//			tensorValue = append(tensorValue, fmt.Sprint(tensorValue, i))
//			tensor := &ViolinInner.InnerTensor{
//				TensorName:  fmt.Sprint("a", i),
//				TensorType:  "string",
//				TensorValue: tensorValue,
//			}
//			inputTensor := []*ViolinInner.InnerTensor{}
//			inputTensor = append(inputTensor, tensor)
//
//			input := &ViolinInner.Input{
//				InputTensors: inputTensor,
//			}
//			inputbatch = append(inputbatch, input)
//			response := route.Dispatch(ViolinInner.Request{
//				Model: &ViolinInner.Model{
//					Name:    "model1",
//					Version: "1001",
//					Type:    "tf",
//				},
//				InputBatch: inputbatch,
//			}, 5*time.Second)
//			if response.OutputBatch != nil {
//				fmt.Println(response.RspCode, response.Msg, ":::", response.OutputBatch[0].OutputNames)
//			} else {
//				fmt.Println(response.RspCode, response.Msg)
//			}
//		}(i)
//
//	}
//
//	hold := make(chan int)
//	<-hold
//
//}
