package test

import (
	"fmt"
	"github.com/julienschmidt/httprouter"
	"math/rand"
	"net/http"
	"strconv"
	"time"
)

//handle all requests
var playLine = make(chan Handler, 10000)

var maxBatchCount = 100
var reachMaxBatchCount = make(chan int, 10000)

type Request struct {
	str string
}
type Response struct {
	batchId string
	result  string
}
type Handler struct {
	req     Request
	timeOut time.Duration
	Done    chan Response
}

func mockClient() {
	for i := 0; i < 10000; i++ {
		//time.Sleep(time.Microsecond * 1)
		go func(clientId int) {
			handler := Handler{
				req:     Request{str: strconv.Itoa(clientId)},
				timeOut: time.Second * 2,
			}

			rsp := execute(handler)

			fmt.Println("client id : " + handler.req.str + " got result : " + rsp.result + " in batch id : " + rsp.batchId)
		}(i)
	}
}

func httpRequestHandler(w http.ResponseWriter, r *http.Request, ps httprouter.Params) {
	buf := make([]byte, r.ContentLength)
	r.Body.Read(buf)
	reqStr := string(buf)

	handler := Handler{
		req:     Request{str: reqStr},
		timeOut: time.Second * 1,
	}

	rsp := execute(handler)
	w.WriteHeader(http.StatusOK)
	fmt.Println("response with a string." + rsp.result)
	fmt.Fprintf(w, "info : %v\n", "result : "+rsp.batchId+" , "+rsp.result)
}

func execute(handler Handler) Response {
	waitingFor := make(chan Response)
	handler.Done = waitingFor
	playLine <- handler

	if len(playLine) >= maxBatchCount {
		reachMaxBatchCount <- 1
	}

	//fmt.Println("now playline length is :", len(playLine))

	select {
	case rsp := <-waitingFor:
		return rsp
	case <-time.After(handler.timeOut):
		return Response{
			result: "timeout",
		}
	}
}

func doWork() {
	ticker := time.NewTicker(time.Millisecond * 1)

	go func() {
		for {
			select {
			case <-reachMaxBatchCount:
				//fmt.Printf("reach max batch count at %v\n", time.Now().String()[:19])
				go doBatch(maxBatchCount)
			default:
				select {
				case <-ticker.C:
					//fmt.Printf("batching ticked at %v\n", time.Now().String()[:19])
					go doBatch(-1)
				}
			}
		}

	}()
}

func doBatch(count int) {
	batchingCount := 0
	if count == -1 {
		batchingCount = len(playLine)
		if batchingCount > maxBatchCount {
			batchingCount = maxBatchCount
		}
	} else {
		batchingCount = count
	}

	fmt.Println("pipeLine length : ", len(playLine))
	fmt.Println("batching length : ", batchingCount)

	batchHandler := []Handler{}

	for i := 0; i < batchingCount; i++ {
		httpHandler := <-playLine
		batchHandler = append(batchHandler, httpHandler)
	}

	responses := doSomething(batchHandler)

	for idx, handler := range batchHandler {
		handler.Done <- responses[idx]

		//go func(Handler,int) {
		//  handler.Done <- responses[idx]
		//}(handler,idx)
	}

}

func doSomething(batching []Handler) []Response {
	randomBatchIdStr := strconv.Itoa(rand.Intn(999999))
	httpResponses := []Response{}
	for idx, _ := range batching {
		res := Response{
			batchId: string(randomBatchIdStr) + " : " + strconv.Itoa(idx),
			result:  strconv.Itoa(rand.Intn(100)),
		}

		httpResponses = append(httpResponses, res)
		//timeoutClients := []string{"2000","5000","9999"}
		//for _,tc := range timeoutClients{
		//  if strings.Compare(tc,handler.req.str) == 0{
		//      //time.Sleep(time.Second * 2)
		//      fmt.Println("123123")
		//  }
		//}
	}
	return httpResponses
}

func mockHttpClient() {
	//启动http服务
	router := httprouter.New()
	router.GET("/", httpRequestHandler)
	http.ListenAndServe(":8080", router)
}

//
//func main() {
//
//	doWork()
//
//	mockClient()
//
//	hold := make(chan int)
//	<-hold
//}
