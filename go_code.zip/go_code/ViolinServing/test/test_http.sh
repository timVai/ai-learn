#/bin/bash!


curl localhost:8080/