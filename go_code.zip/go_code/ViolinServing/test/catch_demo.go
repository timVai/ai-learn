package test

import (
	"fmt"
	"reflect"
)

func testCatchDemo() {
	r, c := service()
	fmt.Println("main code: ", r.code)
	fmt.Println("main msg: ", r.msg)
	fmt.Println("main int value :", c)
}

type result struct {
	code int
	msg  string
}

func service() (r result, c int) {
	defer catch(finally, &r, &c)
	r.code = 1
	r.msg = "doing..."
	doSome(r, c)
	return r, c
}

func doSome(r result, c int) {
	r.code = 200
	r.msg = "before panic"
	c = 200

	panic("i am a panic")

	r.code = 300
	r.msg = "after panic"
	c = 300
}

func finally(s interface{}, r *result, c *int) {
	fmt.Println("finally", s)
	fmt.Println("finally code is : ", r.code)
	r.code = -1
	r.msg = "finally done"
	*c = -10
	fmt.Println("finally code2 is : ", r.code)
}

func catch(finallyFunc ...interface{}) {
	f := reflect.ValueOf(finallyFunc[0])
	errOrPanic := recover()
	if errOrPanic != nil {
		p := make([]reflect.Value, len(finallyFunc))
		p[0] = reflect.ValueOf(errOrPanic)
		for i := 1; i < len(finallyFunc); i++ {
			p[i] = reflect.ValueOf(finallyFunc[i])
		}
		f.Call(p)
	}
}
