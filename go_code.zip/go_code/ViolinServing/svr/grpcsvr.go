package svr

import (
	"ViolinServing/api/proto/service"
	"ViolinServing/config"
	"ViolinServing/logs"
	"fmt"
	"golang.org/x/net/context"
	"google.golang.org/grpc"
	"net"
	"os"
)

type ViolinServiceServerImpl struct{}

func (s *ViolinServiceServerImpl) Predict(ctx context.Context, request *violinservice.Request) (*violinservice.Response, error) {

	return predictNoPanic(request)

}

func predictNoPanic(request *violinservice.Request) (response *violinservice.Response, err error) {
	defer func() {
		e := recover()
		if e != nil {
			fmt.Println(e)
			response.Reset()
			response.RspCode = 505
			response.Msg = "inner Error"
			return
		}
	}()

	res, err := Predict(*request)

	if err != nil {
		response = &violinservice.Response{
			RspCode: -1,
			Msg:     err.Error(),
		}
		err = nil
		return
	}
	response = &res
	return
}

func StartGrpc() {

	v, e := config.Allconfig.Get("grpcport")
	if e != nil {
		logs.LOGGING.Error("not found httpport config")
		os.Exit(-1)
	}

	lis, err := net.Listen("tcp", ":"+v)
	if err != nil {
		//logs.LOGGING.Info("failed to listen: %v", err)
		fmt.Println(err)
	}
	s := grpc.NewServer()
	violinservice.RegisterViolinServiceServer(s, &ViolinServiceServerImpl{})
	s.Serve(lis)
}
