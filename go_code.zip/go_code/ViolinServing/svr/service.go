package svr

import (
	"ViolinServing/api/proto/service"
	"ViolinServing/autobatch"
	"time"
)

func Predict(request violinservice.Request) (violinservice.Response, error) {
	var err error = nil

	response, innerErr := autobatch.Submit(request, time.Second*20)
	if innerErr != nil {
		err = innerErr
		return response, err
	}

	return response, err
}
