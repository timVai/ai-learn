package svr

//
//func StartHttp() {
//
//	v, e := config.Allconfig.Get("httpport")
//	if e != nil {
//		logs.LOGGING.Error("not found httpport config")
//		os.Exit(-1)
//	}
//
//	//启动http服务
//	router := httprouter.New()
//	router.POST("/predict", httpPredict)
//	http.ListenAndServe(":"+v, router)
//}
//
//func httpPredict(w http.ResponseWriter, req *http.Request, ps httprouter.Params) {
//	defer func(writer http.ResponseWriter) {
//		e := recover()
//		if e != nil {
//			httpResponseMap := map[string]interface{}{}
//			httpResponseMap["code"] = "505"
//			httpResponseMap["msg"] = "inner error"
//			writeBack(httpResponseMap, writer)
//		}
//	}(w)
//
//	buf := make([]byte, req.ContentLength)
//	req.Body.Read(buf)
//	jsonData := parser.JsonByteToMap(buf)
//
//	serviceReq := violinservice.Request{}
//
//	serviceReq.Name = jsonData["name"].(string)
//	serviceReq.Type = jsonData["type"].(string)
//	serviceReq.Version = jsonData["version"].(string)
//
//	inputsBytes := ([]byte)(jsonData["inputs"].(string))
//	inputs := parser.JsonByteToArray(inputsBytes)
//
//	for _, input := range inputs {
//		serviceReqTensor := violinservice.Tensor{}
//		serviceReqTensor.TensorName = input["tensorName"].(string)
//		serviceReqTensor.TensorType = input["tensorType"].(string)
//		serviceReqTensor.TensorValue = input["TensorValue"].([]string)
//		serviceReq.Inputs = append(serviceReq.Inputs, &serviceReqTensor)
//	}
//
//	serviceReq.OutputNames = []string{jsonData["outputNames"].(string)}
//
//	httpResponseMap := map[string]interface{}{}
//	rsp, err := Predict(serviceReq)
//
//	if err != nil {
//		httpResponseMap["code"] = string(rsp.RspCode)
//		httpResponseMap["msg"] = rsp.Msg
//		writeBack(httpResponseMap, w)
//	}
//
//	httpResponseMap["code"] = string(rsp.RspCode)
//	httpResponseMap["msg"] = rsp.Msg
//
//	outputs := []map[string]string{}
//	for _, output := range rsp.Outputs {
//		outputInJson := map[string]string{}
//		outputInJson["tensorName"] = output.TensorName
//		outputInJson["tensorType"] = output.TensorType
//		outputInJson["tensorValue"] = output.TensorValue[0]
//		outputs = append(outputs, outputInJson)
//	}
//	httpResponseMap["outputs"] = outputs
//
//	writeBack(httpResponseMap, w)
//}
//
//func writeBack(httpResponse map[string]interface{}, w http.ResponseWriter) {
//	bs := parser.MapToJsonByte(httpResponse)
//	w.WriteHeader(http.StatusOK)
//	w.Write(bs)
//}
