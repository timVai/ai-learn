package tick

import (
	"time"
)

type TickerSupport interface {
	TickCallBack()
}

type tickBus struct {
	//轮训间隔
	ticker *time.Ticker

	//此轮训的所有事件
	events []TickerSupport
}

//todo goroutine unsafe
var tickMap = make(map[time.Duration]*tickBus)

var busStart = make(chan int)

/**
注册特定轮训的事件
*/
func Register(duration time.Duration, event TickerSupport) {
	if tkBus, ok := tickMap[duration]; ok {
		tkBus.events = append(tkBus.events, event)
	} else {
		bus := tickBus{
			ticker: time.NewTicker(duration),
			events: make([]TickerSupport, 0),
		}
		bus.events = append(bus.events, event)
		tickMap[duration] = &bus
		go start(&bus)
	}
}

func start(bus *tickBus) {
	for range bus.ticker.C {
		for _, event := range bus.events {
			go func(e TickerSupport) {
				e.TickCallBack()
			}(event)

		}
	}
}
