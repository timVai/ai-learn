#!/usr/bin/env bash

#osname=$1

if [ ! -f install.sh ]; then
    echo 'install must be run within its container folder' 1>&2
    exit 1
fi

CURPATH="$(cd $(dirname $0); pwd -P)"

#mkdir -p ${CURPATH}/target/bin  ${CURPATH}/target/conf  ${CURPATH}/target/lib ${CURPATH}/target/logs
#
#cd ${CURPATH}/main
#
#exeFile="${CURPATH}/target/bin"
#
#if [[ ${osname} == "linux" ]];then
#   env GOOS=linux GOARCH=amd64 go build -o $exeFile/ViolinRunProcess starter.go
#else
#   go build -o $exeFile/ViolinRunProcess starter.go
#fi
#
#cp ${CURPATH}/conf/* ${CURPATH}/target/conf
#cp ${CURPATH}/lib/*  ${CURPATH}/target/lib



mkdir -p ${CURPATH}/target/model ${CURPATH}/target/bin ${CURPATH}/target/conf ${CURPATH}/target/Logs ${CURPATH}/target/plugin ${CURPATH}/target/includes ${CURPATH}/target/lib

ls -l ${CURPATH}/target/model
echo "pulling default models"

wget -O ${CURPATH}/target/model/BilstmCrf_cmtForbid.pb  'http://storage.jd.local/violinsoft/model/BilstmCrf_cmtForbid.pb?Expires=3694080928&AccessKey=50ksloUitRjTNwzr&Signature=X0G8XpSmcRrg4paytb2oXV0kBgk%3D'
wget -O ${CURPATH}/target/model/emotion.pb 'http://storage.jd.local/violinsoft/model/emotion.pb?Expires=3694081133&AccessKey=50ksloUitRjTNwzr&Signature=F%2BKF90ZsRv4cJtZ0grXQ5Vv9h5A%3D'
wget -O ${CURPATH}/target/model/graph.pb 'http://storage.jd.local/violinsoft/model/graph.pb?Expires=3694081175&AccessKey=50ksloUitRjTNwzr&Signature=2viW5%2B0rejRGXVotMFRy7TgG4jo%3D'


echo "default models pull finish"
ls -l ${CURPATH}/target/model

/bin/cp -rf ${CURPATH}/conf/* ${CURPATH}/target/conf
/bin/cp -f ${CURPATH}/test/plugin_demo/violin_plugin.pc ${CURPATH}/target/plugin/violin_plugin.pc
/bin/cp -f ${CURPATH}/test/plugin_demo/violin_cgo.h ${CURPATH}/target/includes/violin_cgo.h


export GOBIN=${GOPATH}/bin
export PATH=${PATH}:${GOBIN}
export PKG_CONFIG_PATH=${CURPATH}/target/plugin

go install ${CURPATH}/main/violinserving.go


nohup violinserving -confpath ${CURPATH}/target/conf > ${CURPATH}/target/Logs/all.log 2>&1 &


