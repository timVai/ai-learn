package parser

import (
	"encoding/json"
)

func JsonFileToArray(filepath string) []map[string]interface{} {

	data := FileReader(filepath)
	var modelList []map[string]interface{}
	err := json.Unmarshal(data, &modelList)
	if err != nil {
		logging.Error(err)
	}
	return modelList
}

func JsonToMap(filepath string) map[string]interface{} {
	data := FileReader(filepath)

	var modelList map[string]interface{}

	err := json.Unmarshal(data, &modelList)
	if err != nil {
		logging.Error(err)
	}

	return modelList
}

func JsonByteToMap(bs []byte) map[string]interface{} {
	var jsonMap map[string]interface{}
	err := json.Unmarshal(bs, &jsonMap)
	if err != nil {
		logging.Error(err)
	}

	return jsonMap
}

func JsonByteToArray(bs []byte) []map[string]interface{} {
	var jsonMap []map[string]interface{}
	err := json.Unmarshal(bs, &jsonMap)
	if err != nil {
		logging.Error(err)
	}
	return jsonMap
}

func MapToJsonByte(mapData map[string]interface{}) []byte {
	bs, err := json.Marshal(mapData)
	if err != nil {
		logging.Error(err)
	}
	return bs
}
