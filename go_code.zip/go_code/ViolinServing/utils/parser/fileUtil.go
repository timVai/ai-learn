package parser

import (
	"ViolinServing/logs"
	"bufio"
	"io"
	"io/ioutil"
	"net/http"
	"os"
)

var logging = logs.LOGGING

func FileReader(filepath string) []byte {
	data, err := ioutil.ReadFile(filepath)
	if err != nil {
		logging.Error(err)
	}

	return data
}

func DownLoadFile(url, localfilepath string) bool {

	if url == "" || localfilepath == "" {
		logging.Error("url localfilepath can not null")
	}

	res, err := http.Get(url)
	if err != nil {
		logging.Error("http.get error:", err)
		return false
	}
	f, err2 := os.Create(localfilepath)
	if err2 != nil {
		logging.Error("createfile error:", err2)
		return false
	}
	io.Copy(f, res.Body)

	return true
}

func ReadLineAsString(filePth string) ([]string, error) {
	var result []string
	f, err := os.Open(filePth)
	if err != nil {
		return result, err
	}
	defer f.Close()

	bfRd := bufio.NewReader(f)
	for {
		line, err := bfRd.ReadBytes('\n')
		if err != nil {
			break
		}
		result = append(result, string(line))
	}
	return result, err
}

func ReadLineAsBytes(filePth string) ([][]byte, error) {
	var result [][]byte
	f, err := os.Open(filePth)
	if err != nil {
		return result, err
	}
	defer f.Close()

	bfRd := bufio.NewReader(f)
	for {
		line, err := bfRd.ReadBytes('\n')
		if err != nil {
			result = append(result, line)
		}
	}
	return result, nil
}
