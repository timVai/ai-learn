package hub

/*
#cgo pkg-config: violin_plugin
#include "violin_cgo.h"
*/
import "C"

//#include <stdlib.h>
import "C"
import (
	"ViolinServing/api/proto/inner"
	"fmt"
	"github.com/golang/protobuf/proto"
	"runtime"
	"unsafe"
)

// call c lib via cgo will take the current os thread out of pooled thread
//
// LockOSThread can lock thread , and os thread will be terminal  then goroutine dead.
// https://github.com/golang/go/wiki/LockOSThread
func DemoPredict(innerReq ViolinInner.Request) ViolinInner.Response {
	//outbatch := []*ViolinInner.Output{}
	//
	//for i := 0; i < len(innerReq.InputBatch); i++ {
	//	outbatch = append(outbatch, &ViolinInner.Output{
	//		OutputTensors: innerReq.InputBatch[i].InputTensors,
	//		OutputNames:   []string{fmt.Sprint("test", i)},
	//	})
	//}
	//
	//return ViolinInner.Response{
	//	RspCode:     0,
	//	Msg:         "ok",
	//	OutputBatch: outbatch,
	//}

	return ViolinInner.Response{
		RspCode: 0,
		Msg:     "ok",
	}
}

func Predict(innerReq ViolinInner.Request) ViolinInner.Response {
	runtime.LockOSThread()

	var innerRsp ViolinInner.Response
	reqBytes, error := proto.Marshal(&innerReq)
	if error != nil {
		innerRsp = ViolinInner.Response{}
		innerRsp.RspCode = -100
		innerRsp.Msg = "error occur in innerRequest object parsing to byte array"
		return innerRsp
	}

	reqStruct := C.struct_Req{}
	reqStruct.len = C.int(len(reqBytes))
	reqStruct.in_ptr = (*C.uchar)(unsafe.Pointer(&reqBytes[0]))

	var rsp_ptr unsafe.Pointer
	defer C.freeRsp(rsp_ptr)

	//call C
	C.predict(reqStruct, &rsp_ptr)

	runtime.KeepAlive(reqStruct)

	rspGoPtr := (*C.struct_Rsp)(rsp_ptr)

	rspPbBytes := C.GoBytes(unsafe.Pointer(rspGoPtr.out_ptr), rspGoPtr.len)

	unmarshalError := proto.Unmarshal(rspPbBytes, &innerRsp)
	if unmarshalError != nil {
		innerRsp.Reset()
		innerRsp.RspCode = -200
		innerRsp.Msg = "error occur in ViolinCgo.Response.XXX_Unmarshal"
		fmt.Println("c api warp invoked,but got a wrong bytes", rspPbBytes)
		return innerRsp
	}

	return innerRsp
}

func LoadModel(innerModel ViolinInner.Model) ViolinInner.ModelStatus {
	runtime.LockOSThread()

	modelStatus := ViolinInner.ModelStatus{}
	innerModelBytes, error := proto.Marshal(&innerModel)
	if error != nil {
		modelStatus.ModeStatus = -1
		modelStatus.Msg = "error occur in c api LoadModel"
		return modelStatus
	}

	reqStruct := C.struct_Req{}
	reqStruct.len = C.int(len(innerModelBytes))
	reqStruct.in_ptr = (*C.uchar)(unsafe.Pointer(&innerModelBytes[0]))

	var rsp_ptr unsafe.Pointer
	defer C.freeRsp(rsp_ptr)

	//call C
	C.load(reqStruct, &rsp_ptr)

	runtime.KeepAlive(reqStruct)

	rspGoPtr := (*C.struct_Rsp)(rsp_ptr)

	rspPbBytes := C.GoBytes(unsafe.Pointer(rspGoPtr.out_ptr), rspGoPtr.len)

	unmarshalError := modelStatus.XXX_Unmarshal(rspPbBytes)
	if unmarshalError != nil {
		modelStatus.Reset()
		modelStatus.ModeStatus = -1
		modelStatus.Msg = "error occur in c api LoadModel return wrong data"
		fmt.Println("c api warp LoadModel invoked,but got a wrong bytes", rspPbBytes)
		return modelStatus
	}
	return modelStatus
}

func UnLoadModel(innerModel ViolinInner.Model) ViolinInner.ModelStatus {
	runtime.LockOSThread()

	modelStatus := ViolinInner.ModelStatus{}
	reqBytes, error := proto.Marshal(&innerModel)
	if error != nil {
		modelStatus.ModeStatus = -1
		modelStatus.Msg = "error occur in c api UnLoadModel"
		return modelStatus
	}

	reqStruct := C.struct_Req{}
	reqStruct.len = C.int(len(reqBytes))
	reqStruct.in_ptr = (*C.uchar)(unsafe.Pointer(&reqBytes[0]))

	var rsp_ptr unsafe.Pointer
	defer C.freeRsp(rsp_ptr)

	//call C
	C.unload(reqStruct, &rsp_ptr)

	runtime.KeepAlive(reqStruct)

	rspGoPtr := (*C.struct_Rsp)(rsp_ptr)

	rspPbBytes := C.GoBytes(unsafe.Pointer(rspGoPtr.out_ptr), rspGoPtr.len)

	unmarshalError := modelStatus.XXX_Unmarshal(rspPbBytes)
	if unmarshalError != nil {
		modelStatus.Reset()
		modelStatus.ModeStatus = -1
		modelStatus.Msg = "error occur in c api UnLoadModel return wrong data"
		fmt.Println("c api warp UnLoadModel invoked,but got a wrong bytes", rspPbBytes)
		return modelStatus
	}

	return modelStatus
}

//
//func Predict(innerReq ViolinInner.Request) ViolinInner.Response {
//	outbatch := []*ViolinInner.Output{}
//	innerRsp := ViolinInner.Response{}
//	innerRsp.RspCode = 0
//	innerRsp.Msg = "ok"
//	for i:=0;i<len(innerReq.InputBatch);i++{
//		outbatch= append(outbatch, &ViolinInner.Output{
//			OutputTensors: innerReq.InputBatch[i].InputTensors,
//			OutputNames:[]string{fmt.Sprint("test",i)},
//		})
//	}
//	return innerRsp
//}
//
//func LoadModel(innerModel ViolinInner.Model) ViolinInner.ModelStatus {
//	modelStatus := ViolinInner.ModelStatus{}
//	modelStatus.ModeStatus = 0
//	modelStatus.Msg = "error occur in c api LoadModel return wrong data"
//	return modelStatus
//}
//
//func UnLoadModel(innerModel ViolinInner.Model) ViolinInner.ModelStatus {
//	modelStatus := ViolinInner.ModelStatus{}
//	modelStatus.ModeStatus = 0
//	modelStatus.Msg = "error occur in c api UnLoadModel return wrong data"
//	return modelStatus
//}
