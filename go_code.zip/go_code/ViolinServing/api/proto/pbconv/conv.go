package pbconv

import (
	"ViolinServing/api/proto/inner"
	"ViolinServing/api/proto/service"
	"errors"
)

//
func ServiceReq2innerReq(serviceRequests []violinservice.Request) (innerRequest ViolinInner.Request, e error) {
	if serviceRequests == nil || len(serviceRequests) == 0 {
		return innerRequest, errors.New("nil serviceRequests")
	}

	model := buildModelInfo(serviceRequests)
	inputTensorMap := make(map[string]*ViolinInner.InnerTensor)
	paramMap := make(map[string]string)
	xName := make([]string, 0)
	var yName []string

	for _, serviceInputTensor := range serviceRequests[0].GetInputs() {
		xName = append(xName, serviceInputTensor.TensorName)
	}
	yName = serviceRequests[0].OutputNames

	for _, req := range serviceRequests { //each request
		for _, input := range req.GetInputs() { // each input in one request
			//create inner tensor if see new TensorName
			if _, ok := inputTensorMap[input.TensorName]; !ok {
				inputTensorMap[input.TensorName] = &ViolinInner.InnerTensor{
					TensorName: input.TensorName,
				}
			}

			innerTensorValue := ViolinInner.TensorValue{Items: input.TensorValue}

			//if input.TensorName == "sequence_lengths" && len(inputTensorMap[input.TensorName].TensorValues) == 1{
			//
			//}else{
			//	inputTensorMap[input.TensorName].TensorValues = append(inputTensorMap[input.TensorName].TensorValues, &innerTensorValue)
			//}

			inputTensorMap[input.TensorName].TensorValues = append(inputTensorMap[input.TensorName].TensorValues, &innerTensorValue)

			inputTensorMap[input.TensorName].Dims = input.Dim
			inputTensorMap[input.TensorName].Dtype = conv2InnerDType(input.TensorType)
		}
	}

	innerRequest = ViolinInner.Request{
		Model:       &model,
		InputTensor: inputTensorMap,
		Parameters:  paramMap,
		XName:       xName,
		YName:       yName,
	}

	return innerRequest, e
}

func InnerRsp2ServiceRsp(response ViolinInner.Response) (rsps []violinservice.Response, e error) {
	//if response == nil {
	//	return rsp,errors.New("error")
	//}
	yNames := response.YName
	outputTensorMap := response.GetOutputTensor()

	batchSize := len(outputTensorMap[yNames[0]].GetTensorValues())

	//一个batch中存batchSize个response的数据,rspSeq是当前响应数据在batch中的index
	for batchIdx := 0; batchIdx < batchSize; batchIdx++ {

		rsp := violinservice.Response{
			RspCode: response.RspCode,
			Msg:     "ok",
		}

		for _, y := range yNames {
			serviceTensor := violinservice.Tensor{
				TensorName:  y,
				TensorType:  conv2ServiceDType(outputTensorMap[y].Dtype),
				Dim:         outputTensorMap[y].Dims,
				TensorValue: outputTensorMap[y].GetTensorValues()[batchIdx].Items,
			}
			rsp.Outputs = append(rsp.Outputs, &serviceTensor)
		}
		rsps = append(rsps, rsp)
	}
	return rsps, e
}

func buildModelInfo(serviceRequests []violinservice.Request) ViolinInner.Model {
	model := ViolinInner.Model{}
	model.Name = serviceRequests[0].Name
	model.Version = serviceRequests[0].Version

	return model
}

func ConvModelType(modelType violinservice.ModelType) ViolinInner.ModelType {
	switch modelType {
	case violinservice.ModelType_TENSORFLOW:
		return ViolinInner.ModelType_TENSORFLOW
	case violinservice.ModelType_PYTORCH:
		return ViolinInner.ModelType_PYTORCH
	case violinservice.ModelType_CAFFE2:
		return ViolinInner.ModelType_CAFFE2
	case violinservice.ModelType_ONNX:
		return ViolinInner.ModelType_ONNX
	}
	panic("ConvModelType error")
}

func conv2InnerDType(serviceDType violinservice.DType) ViolinInner.DType {
	switch serviceDType {
	case violinservice.DType_int8:
		return ViolinInner.DType_int8
	case violinservice.DType_int16:
		return ViolinInner.DType_int16
	case violinservice.DType_int32:
		return ViolinInner.DType_int32
	case violinservice.DType_int64:
		return ViolinInner.DType_int64
	case violinservice.DType_float16:
		return ViolinInner.DType_float16
	case violinservice.DType_float32:
		return ViolinInner.DType_float32
	case violinservice.DType_float64:
		return ViolinInner.DType_float64
	}
	panic("Dtype Error")
}

func conv2ServiceDType(innerDType ViolinInner.DType) violinservice.DType {
	switch innerDType {
	case ViolinInner.DType_int8:
		return violinservice.DType_int8
	case ViolinInner.DType_int16:
		return violinservice.DType_int16
	case ViolinInner.DType_int32:
		return violinservice.DType_int32
	case ViolinInner.DType_int64:
		return violinservice.DType_int64
	case ViolinInner.DType_float16:
		return violinservice.DType_float16
	case ViolinInner.DType_float32:
		return violinservice.DType_float32
	case ViolinInner.DType_float64:
		return violinservice.DType_float64
	}
	panic("Dtype Error")
}

func ConvStr2InnerMT(modelType string) ViolinInner.ModelType {
	if "tensorflow" == modelType {
		return ViolinInner.ModelType_TENSORFLOW
	} else if "pytorch" == modelType {
		return ViolinInner.ModelType_PYTORCH
	} else if "caffe2" == modelType {
		return ViolinInner.ModelType_CAFFE2
	} else if "onnx" == modelType {
		return ViolinInner.ModelType_ONNX
	} else {
		panic("ConvStr2InnerMT error with param " + modelType)
	}
}
