#!/bin/bash

modelType=$1

SERVING_APP_PATH="$(cd $(dirname $0)/..; pwd -P)"
. ${HOME}/.profile

pid=`ps aux | grep violinserving | grep -v grep | awk -F" " '{print $2}'`
if [ ! -z ${pid} ];then
    kill -9 ${pid}
fi

mkdir -p /App/Violin/bin /App/Violin/conf /App/soft /export/model /export/Logs
/bin/cp -rf ${SERVING_APP_PATH}/conf/* /App/Violin/conf
/bin/cp -f ${SERVING_APP_PATH}/plugin/${modelType}/pkgconfig/violin_plugin_${modelType}.pc ${SERVING_APP_PATH}/plugin/violin_plugin.pc

go install ${SERVING_APP_PATH}/main/violinserving.go

nohup violinserving -confpath /App/Violin/conf > /export/Logs/all.log 2>&1 &