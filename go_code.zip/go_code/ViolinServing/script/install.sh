#!/bin/bash

echo "install golang1.11.4 ..."
wget -O /App/soft/go1.11.4.linux.amd64.tar.gz  'http://storage.jd.local/violinsoft/go1.11.4.linux-amd64.tar.gz?Expires=3694079303&AccessKey=50ksloUitRjTNwzr&Signature=KSQR2cXcpBFlmiN%2Bm8N%2B%2FUn3i2Y%3D'
wget -O /App/soft/pkg-config-0.29.2.tar  'http://storage.jd.local/docker-app/pkg-config-0.29.2.tar?Expires=3695649181&AccessKey=s520WKgV5obMH4GI&Signature=SdJImimSk%2BbevDmqmQYLdhcNVo4%3D'

tar zxvf /App/soft/go1.11.4.linux.amd64.tar.gz -C /App/soft
tar xvf /App/soft/pkg-config-0.29.2.tar -C /App/soft

cd /App/soft/pkg-config-0.29.2
./configure  --with-internal-glib
make
make install
