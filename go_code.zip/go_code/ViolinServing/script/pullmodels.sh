#!/bin/bash

set -e
. $HOME/.profile

if [ -f "/export/App/bin/pullmodels.sh" ];then
    echo "found /export/App/bin/pullmodels.sh , pulling models ... "
    sh /export/App/bin/pullmodels.sh
fi

mkdir -p /export/model
ls -l /export/model
echo "pulling default models"

wget -O /export/model/BilstmCrf_cmtForbid.pb  'http://storage.jd.local/violinsoft/model/BilstmCrf_cmtForbid.pb?Expires=3694080928&AccessKey=50ksloUitRjTNwzr&Signature=X0G8XpSmcRrg4paytb2oXV0kBgk%3D'
wget -O /export/model/emotion.pb 'http://storage.jd.local/violinsoft/model/emotion.pb?Expires=3694081133&AccessKey=50ksloUitRjTNwzr&Signature=F%2BKF90ZsRv4cJtZ0grXQ5Vv9h5A%3D'
wget -O /export/model/graph.pb 'http://storage.jd.local/violinsoft/model/graph.pb?Expires=3694081175&AccessKey=50ksloUitRjTNwzr&Signature=2viW5%2B0rejRGXVotMFRy7TgG4jo%3D'


echo "default models pull finish"
ls -l /export/model