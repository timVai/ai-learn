#!/bin/bash
set -e
SERVING_APP_PATH="$(cd $(dirname $0)/..; pwd -P)"

. ${HOME}/.profile

#install
#sh ${SERVING_APP_PATH}/script/install.sh

#models
sh ${SERVING_APP_PATH}/script/pullmodels.sh


######run#####
sh ${SERVING_APP_PATH}/script/start.sh tensorflow
