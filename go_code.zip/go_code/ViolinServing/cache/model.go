package cache

import (
	"ViolinServing/api/proto/inner"
	"strings"
	"time"
)

/*
源类型
*/
type SourceTypeEnum string

const (
	SourceType_FILE    SourceTypeEnum = "file"    //本地文件类型
	SourceType_NETWORK                = "network" //网络流
)

/*
源信息
*/
type Source struct {
	SourceType SourceTypeEnum
	Url        string
	LocalPath  string
}

/*
加载信息
*/
type LoadInfo struct {
	LoadTs time.Time
}

/*
模型信息
*/
type ModelBaseInfo struct {
	ModelType    ViolinInner.ModelType
	ModelName    string
	ModelVersion string
}

/*
模型信息
*/
type ModelCache struct {
	ModelSource Source
	ModelInfo   ModelBaseInfo
	LoadInfo    LoadInfo
	CanBatch    bool
	cacheTime   time.Time
}

const sep string = "@"

func GenModelToken(base ModelBaseInfo) string {
	return base.ModelType.String() + sep + base.ModelName + sep + base.ModelVersion
}

func StoSourceTypeEnum(st string) SourceTypeEnum {
	if strings.Compare(st, "local") == 0 {
		return SourceType_FILE
	} else {
		return SourceType_NETWORK
	}
}
