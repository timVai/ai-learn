/*
  @File : modelcache.go
  @Author : zhangwenjie10
  @Date : 2018-12-13
  @Desc: 缓存模型信息
*/
package cache

import (
	"errors"
	"time"
)

var ModelInfoCache = make(map[string]ModelCache)

func Add(modelCache ModelCache) bool {
	key := GenModelToken(modelCache.ModelInfo)

	if _, ok := ModelInfoCache[key]; ok {
		return false
	} else {
		modelCache.cacheTime = time.Now()
		ModelInfoCache[key] = modelCache
		return true
	}
}

func Get(baseInfo ModelBaseInfo) (*ModelCache, error) {
	if v, ok := ModelInfoCache[GenModelToken(baseInfo)]; ok {
		return &v, nil
	} else {
		return nil, errors.New("no such key")
	}
}

func Delete(baseInfo ModelBaseInfo) {
	delete(ModelInfoCache, GenModelToken(baseInfo))
}
