package common

import "reflect"

/**
假设你的业务方法如下：
service() (result ResultStruct , state int){
	doSomething()
}

引入catch finally方式分两步：

一、声明errHandler(param1 interface{},param2 interface{})

	func errHandler(err interface{}){
		fmt.Print(err)
	}
	或
	func errHandler(err interface{} , result *ResultStruct , state *int){
		result.msg = "系统小憩中，您可稍后操作。"
		*state = 500
	}

二、业务方法修改如下：
	service() (result ResultStruct , state int) {
		//param1,param2 可以传入业务方法的返回值，这样可以在handler中修改业务方法返回值。
		defer Catch(errHandler,param1,param2)
		doSomething()
	}


Catch可以帮你recover panic，并且友好的交给errHandler去处理，在handler中你可以做必要的异常处理。

注意：方法中使用到反射，性能消耗暂未测试。
*/
func Catch(finallyFunc ...interface{}) {
	f := reflect.ValueOf(finallyFunc[0])
	errOrPanic := recover()
	if errOrPanic != nil {
		p := make([]reflect.Value, len(finallyFunc))
		p[0] = reflect.ValueOf(errOrPanic)
		for i := 1; i < len(finallyFunc); i++ {
			p[i] = reflect.ValueOf(finallyFunc[i])
		}
		f.Call(p)
	}
}
