#!/usr/bin/env bash

#1、检查是否具备go编译环境，检查安装dep工具
if ! [ -x "$(command -v go)" ]; then
  echo 'Error: go is not installed.' >&2
  exit 1
fi

PREPATH=`cd $(dirname $0)/..; pwd`
SRCPATH=`echo $PREPATH| awk -F "/" '{print $NF}'`
if [[ "src" != $SRCPATH ]]; then

   read -p "The current project is not in the GOPATH/src directory, please enter your local GOPATH/src directory here : "
   PREPATH=$REPLY

#   echo "Error: Pleace move the current project to GOPATH/src directory." >&2
#   exit 1
fi


GO_PATH=`cd ${PREPATH}/..; pwd`
export GOPATH="$GO_PATH"

#2、通过dep工具检查依赖的三方包是否下载完成
#1) 本地安装dep
if ! [ -x "$(command -v dep)" ]; then
  echo "dep is not installed, start installing dep"
  go get -u github.com/golang/dep/cmd/dep
fi

#2）执行dep更新依赖包
dep ensure -update -v

#3) 打印全部依赖包
dep status

echo "\nInitialization successful！\n"

