/*
  @File : monitor.go
  @Author : zhangwenjie10
  @Date : 2018-12-13
  @Desc:
*/
package modelmanage

import (
	"ViolinServing/api/hub"
	"ViolinServing/api/proto/inner"
	"ViolinServing/api/proto/pbconv"
	"ViolinServing/autobatch"
	"ViolinServing/cache"
	"ViolinServing/config"
	"ViolinServing/logs"
	"ViolinServing/utils/parser"
	"fmt"
	"path/filepath"
	"runtime"
	"strings"
	"sync/atomic"
	"time"
)

var logging = logs.LOGGING

//模型原子操作
var running int32

func convert(modelFromFile map[string]interface{}) cache.ModelCache {
	modelType := modelFromFile["modelType"].(string)
	modelName := modelFromFile["modelName"].(string)
	modelVersion := modelFromFile["modelVersion"].(string)
	modelPath := modelFromFile["modelPath"]
	remotePath := modelFromFile["remotePath"]
	mode := modelFromFile["mode"].(string)
	sourceType := cache.StoSourceTypeEnum(modelFromFile["sourceType"].(string))

	modelCaching := cache.ModelCache{
		ModelSource: cache.Source{
			SourceType: sourceType,
			LocalPath: func(mp interface{}) string {
				if mp != nil {
					return mp.(string)
				} else {
					return ""
				}
			}(modelPath),
			Url: func(rp interface{}) string {
				if rp != nil {
					return rp.(string)
				} else {
					return ""
				}
			}(remotePath),
		},
		ModelInfo: cache.ModelBaseInfo{
			ModelType:    pbconv.ConvStr2InnerMT(modelType),
			ModelName:    modelName,
			ModelVersion: modelVersion,
		},
		CanBatch: func(mode string) bool {
			if strings.Compare("batch", mode) == 0 {
				return true
			} else {
				return false
			}
		}(mode),
	}
	return modelCaching
}

func load(model cache.ModelCache) {
	innerReqModel := ViolinInner.Model{}
	innerReqModel.Name = model.ModelInfo.ModelName
	innerReqModel.Type = model.ModelInfo.ModelType
	innerReqModel.Version = model.ModelInfo.ModelVersion
	innerReqModel.Path = model.ModelSource.LocalPath

	response := hub.LoadModel(innerReqModel)
	if response.ModeStatus == 0 {
		logging.Info("加载模型成功>>>>模型名称：", model.ModelInfo.ModelName,
			"模型版本：", model.ModelInfo.ModelVersion, "模型类型：", model.ModelInfo.ModelType)

		//模型状态
		model.LoadInfo = cache.LoadInfo{
			LoadTs: time.Now(),
		}
		cache.Add(model)

		autobatch.RegRouter(model.ModelInfo)
	} else {
		logging.Error("模型加载失败", response.Msg)
	}
}

/*
 先清除内存标志，停止对此模型的底层请求。
*/
func unload(model cache.ModelCache) {

	//清除内存中的模型信息
	cache.Delete(model.ModelInfo)
	//注销模型对应的路由
	autobatch.UnRegRouter(model.ModelInfo)

	//给当前请求的响应时间
	time.Sleep(time.Second * 1)

	innerReqModel := ViolinInner.Model{}
	innerReqModel.Name = model.ModelInfo.ModelName
	innerReqModel.Type = model.ModelInfo.ModelType
	innerReqModel.Version = model.ModelInfo.ModelVersion
	response := hub.UnLoadModel(innerReqModel)
	if response.ModeStatus == 0 {
		logging.Info("卸载模型成功 <<<<模型名称：", model.ModelInfo.ModelName,
			"模型版本：", model.ModelInfo.ModelVersion, "模型类型：", model.ModelInfo.ModelType)
	} else {
		logging.Error("模型", model.ModelInfo.ModelName, "卸载失败,msg:", response.Msg)
	}
}

type ModelTick struct {
}

func (t *ModelTick) TickCallBack() {
	ModelManage()
}

func ModelManage() {
	//拿到模型更新锁
	swapFlag := atomic.CompareAndSwapInt32(&running, 0, 1)
	if !swapFlag {
		return
	}
	fmt.Println("runtime.NumCgoCall()", runtime.NumCgoCall())
	var modelFromFile = make(map[string]cache.ModelCache)

	modelConfigFromFile := parser.JsonFileToArray(filepath.Join(config.GlobalConfigpath, "model-config.json"))

	for _, modelConfig := range modelConfigFromFile {
		modelCaching := convert(modelConfig)
		prepareToLoad(modelCaching)
		modelFromFile[cache.GenModelToken(modelCaching.ModelInfo)] = modelCaching
	}

	//加载模型
	for _, model := range modelFromFile {
		_, e := cache.Get(model.ModelInfo)
		if e != nil {
			load(model)
		}
		logging.Info("Monitor .....")
	}

	//卸载 内存中有配置文件中没有的模型
	for _, modelInCache := range cache.ModelInfoCache {
		if _, ok := modelFromFile[cache.GenModelToken(modelInCache.ModelInfo)]; ok {
			//fmt.Println("already load")
		} else {
			unload(modelInCache)
		}
	}

	swapFlag = atomic.CompareAndSwapInt32(&running, 1, 0)
	if !swapFlag {
		fmt.Println("释放扫描标志失败！！")
	}

}

func prepareToLoad(model cache.ModelCache) {
	source := model.ModelSource

	if source.SourceType == cache.SourceType_NETWORK {

		_, e := cache.Get(model.ModelInfo)
		if e != nil {
			ok := parser.DownLoadFile(source.Url, source.LocalPath)
			if !ok {
				logging.Error("模型下载失败：", cache.GenModelToken(model.ModelInfo))
			}
			logging.Info("模型下载成功：", cache.GenModelToken(model.ModelInfo))
		}
	}
}
