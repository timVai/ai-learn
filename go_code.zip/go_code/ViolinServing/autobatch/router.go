package autobatch

import (
	"ViolinServing/api/proto/service"
)

type RouteHandler struct {
	RawReq violinservice.Request
	RawRsp chan violinservice.Response
}

//main auto batch router
type ViolinRouter struct {
	Index int64
	//最大batch限制
	BatchSize    int32
	IntervalMicS int64
	HandlerChan  chan RouteHandler
	Active       bool
	MicroStep    int64
}

// build a router , each model has only one router
func NewRouter(batchSize int32, intervalMicS int64) *ViolinRouter {
	router := &ViolinRouter{
		Index:        int64(0),
		BatchSize:    batchSize,
		IntervalMicS: intervalMicS,
		MicroStep:    int64(0),
	}
	router.Init(batchSize, intervalMicS)
	return router
}

func (router *ViolinRouter) Init(batchSize int32, intervalMS int64) bool {
	if router.Active {
		return false
	}
	if batchSize == 0 {
		return false
	}
	router.HandlerChan = make(chan RouteHandler, batchSize)
	router.Active = true
	return true
}
