package autobatch

import (
	"ViolinServing/api/hub"
	"ViolinServing/api/proto/inner"
	"ViolinServing/api/proto/pbconv"
	"ViolinServing/api/proto/service"
	"ViolinServing/logs"
	"math"
	"strconv"
	"sync/atomic"
	"time"
)

var log = logs.LOGGING

func (router *ViolinRouter) Dispatch(req violinservice.Request, timeout time.Duration) violinservice.Response {
	// 构建请求
	handler := RouteHandler{}
	handler.RawReq = req
	handler.RawRsp = make(chan violinservice.Response, 1)
	router.HandlerChan <- handler

	select {
	case response := <-handler.RawRsp:
		return response
	case <-time.After(timeout):
		return violinservice.Response{
			RspCode: -1,
			Msg:     "time out!",
		}
	}
}

func (router *ViolinRouter) TickCallBack() {
	router.BatchStep()
}

func (router *ViolinRouter) BatchStep() {
	if router.MicroStep >= math.MaxInt64 {
		router.MicroStep = 0
	}

	batchSize := router.BatchSize
	handlerChan := router.HandlerChan
	requestLen := len(handlerChan)
	timeInterval := router.IntervalMicS

	if requestLen > 0 {
		// 批次发送 或 定时发送
		go func(microSec int64, requestLen int, handlerChan chan RouteHandler) {
			println("batch size : ", requestLen)
			if requestLen >= int(batchSize) || (microSec != 0 && microSec%timeInterval == 0) {
				router.Index += 1
				//debugMsg := fmt.Sprintf("start batch [%d] send.....", requestLen)
				//fmt.Println("auto batch run: %s", debugMsg)

				routeHandlers := make([]RouteHandler, 0)
				serviceReqs := make([]violinservice.Request, 0)
				for i := 0; i < requestLen; i++ {
					h := <-handlerChan
					routeHandlers = append(routeHandlers, h)
					serviceReqs = append(serviceReqs, h.RawReq)
				}

				innerRequest, err := pbconv.ServiceReq2innerReq(serviceReqs)

				var innerResponse ViolinInner.Response
				if err == nil {
					//调用c方法  返回response
					//innerResponse := hub.DemoPredict(innerRequest)
					innerResponse = hub.Predict(innerRequest)
				} else {
					innerResponse = ViolinInner.Response{
						RspCode: -1,
						Msg:     "auto batch error",
					}
				}

				serviceRsps, err := pbconv.InnerRsp2ServiceRsp(innerResponse)

				for index, serviceRsp := range serviceRsps {
					h := routeHandlers[index]
					ext := strconv.FormatInt(router.Index, 10)
					go WriteBackResponse(h, serviceRsp, ext)
				}
			}

		}(router.MicroStep, requestLen, handlerChan)
	} else {
		//if router.MicroStep%int64(200*1000) == 0 {
		//	infoMsgMoni := fmt.Sprintf("monitor [%d] send.....%d ", requestLen, router.MicroStep)
		//	fmt.Println("auto batch run: %s", infoMsgMoni)
		//}
	}

	atomic.AddInt64(&router.MicroStep, 1)
}

func WriteBackResponse(h RouteHandler, rsp violinservice.Response, ext string) {
	h.RawRsp <- rsp
}
