/*
  @File : factory.go
  @Author : zhangwenjie10
  @Date : 2018-12-20
  @Desc:
*/

package autobatch

import (
	"ViolinServing/api/hub"
	"ViolinServing/api/proto/pbconv"
	"ViolinServing/api/proto/service"
	"ViolinServing/cache"
	"ViolinServing/tick"
	"errors"
	"time"
)

var RouterMap = make(map[string]*ViolinRouter)

func RegRouter(modelInfo cache.ModelBaseInfo) {
	var key = cache.GenModelToken(modelInfo)

	if RouterMap[key] == nil {
		router := NewRouter(int32(500), 1)
		RouterMap[key] = router

		tick.Register(time.Microsecond*200, router)
	}
}

func UnRegRouter(modelInfo cache.ModelBaseInfo) {
	var key = cache.GenModelToken(modelInfo)
	delete(RouterMap, key)
}

func Submit(req violinservice.Request, timeout time.Duration) (violinservice.Response, error) {
	var err error = nil

	predictModelInfo := cache.ModelBaseInfo{}
	predictModelInfo.ModelName = req.Name
	predictModelInfo.ModelVersion = req.Version
	//predictModelInfo.ModelType = ViolinInner.ModelType //req.Type.String()

	cachedModel, notExist := cache.Get(predictModelInfo)
	if notExist != nil {
		err = errors.New("no such model")
		return violinservice.Response{}, err
	}

	batchFlag := cachedModel.CanBatch
	if batchFlag {
		batchRouter := RouterMap[cache.GenModelToken(predictModelInfo)]
		return batchRouter.Dispatch(req, timeout), err
	} else {

		reqs := make([]violinservice.Request, 0)
		reqs = append(reqs, req)
		innerReq, _ := pbconv.ServiceReq2innerReq(reqs)

		innerRsp := hub.Predict(innerReq)
		rsps, err := pbconv.InnerRsp2ServiceRsp(innerRsp)

		return rsps[0], err
	}

}
