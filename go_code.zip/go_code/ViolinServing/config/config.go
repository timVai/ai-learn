/*
  @File : config.go
  @Author : zhangwenjie10
  @Date : 2018-12-13
  @Desc: 解析模型配置文件conf.yaml
*/
package config

import (
	"flag"
	"fmt"
	"github.com/kylelemons/go-gypsy/yaml"
	"path/filepath"
)

var (
	Allconfig        *yaml.File
	GlobalConfigpath string
)

func init() {
	configpath := flag.String("confpath", "conf", "a string")
	flag.Parse()
	path, _ := filepath.Abs(*configpath)
	GlobalConfigpath = path
}

func LoadConfig() {
	config, err := yaml.ReadFile(filepath.Join(GlobalConfigpath, "conf.yaml"))
	if err != nil {
		fmt.Println(err)
	}
	Allconfig = config
}
