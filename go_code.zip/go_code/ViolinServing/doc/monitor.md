## 监控

系统监控规划：主要使用ump方式统计监控。

监控内容：

| 系统监控项     | 数据来源       | 查看方式 |
| -------------- | -------------- | -------- |
| goroutine数量  | go runtime api |          |
| cgo invoke Num | go runtime api |          |
| threads        | go runtime api |          |
| GC Num         | go runtime api |          |
| heap           | go runtime api |          |
| block          | go runtime api |          |
| CPU            | mdc.jd.com     |          |
| MEM            | mdc.jd.com     |          |
| NETWORK        | mdc.jd.com     |          |





| 业务监控项                   | 数据来源       |      |
| ---------------------------- | -------------- | ---- |
| 系统模型信息（加载模型个数） | 暴露查询接口   |      |
| autoBatchSize                | 暴露查询接口   |      |
| panic报警                    | 落地ump报警key |      |

