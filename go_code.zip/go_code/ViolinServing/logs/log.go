package logs

import (
	"ViolinServing/config"
	lg4g "github.com/jeanphorn/log4go"
	"path/filepath"
)

var LOGGING lg4g.Logger

/**
  根据配置文件初始化log4go
*/
func init() {

	lg4g.LoadConfiguration(filepath.Join(config.GlobalConfigpath,"log4go.json"))

	LOGGING = lg4g.Global

	LOGGING.Info("load log4go.json")
	//logger := make(lg4g.Logger)
	//logger.AddFilter("std.out",lg4g.DEBUG, lg4g.NewConsoleLogWriter())
}
