mac install:
./configure --with-internal-glib
make
make check
make install




pkg-config will search file voilin.pc in `PKG_CONFIG_PATH`

