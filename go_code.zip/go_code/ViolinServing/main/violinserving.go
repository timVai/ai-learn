package main

import (
	"ViolinServing/config"
	"ViolinServing/modelmanage"
	"ViolinServing/svr"
	"ViolinServing/tick"
	"log"
	"net/http"
	_ "net/http/pprof"
	"time"
)

func main() {
	startPProf()

	//Load configuration information
	config.LoadConfig()

	//First loading model
	modelmanage.ModelManage()

	//Start the model management service
	tick.Register(time.Second*5, &modelmanage.ModelTick{})

	//start grpc server
	go svr.StartGrpc()

	////start http server
	//go svr.StartHttp()

	hold := make(chan int)
	<-hold
}

func startPProf() {

	go func() {
		log.Println(http.ListenAndServe("0.0.0.0:6060", nil))
	}()
}
