package main

import (
	"ViolinServing/test"
	"fmt"
)

func main() {

	//test.TestTick()
	test.IndexCase1()
	//test.TestGrpc()

	//test.TestPredictMultiOutput()
	//test.TestNewPredict()
	//for i := 0; i < 100; i++ {
	//	go test.TestGrpc2()
	//	time.Sleep(time.Millisecond * 1)
	//}
	//
	fmt.Println("unit test finish")
	hold := make(chan int)
	<-hold
}
