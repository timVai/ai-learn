#!/usr/bin/env bash

set -e

cd /root
wget -O "violin.ssh.tar.gz" "http://storage.jd.local/docker-app/violin.ssh.tar.gz?Expires=3694070493&AccessKey=s520WKgV5obMH4GI&Signature=ypHj5HhQmF4dBOWR68dXrI0AcsI%3D"
tar -zxvf violin.ssh.tar.gz
chmod 700 ~/.ssh
chmod 600 ~/.ssh/id_rsa
mkdir -p /App/Violin/src/violin-release
cd /App/Violin/src/violin-release
git clone git@code.jd.com:violin/ViolinPlugins.git
sh ViolinPlugins/tools/build.sh
sh ViolinPlugins/tools/deploy.sh
git clone git@code.jd.com:violin/ViolinServing.git
