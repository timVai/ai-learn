#!/usr/bin/python
#-*- coding: utf-8 -*-

__author__ = "ghostwwl"

import os
import stat
import sys
import getopt
import datetime
import hashlib
import requests
import base64
import hmac
import ujson as json

ISPY3 = sys.version_info >= (3,)

class OSS_Client(object):
    def __init__(self, secret_key, access_key):
        '''
        京东对象存储
        :param secret_key: 应用的secret_key
        :param access_key: 应用的access_key
        '''
        self.ROOT_PAHT = "http://storage.jd.local"
        self.SECRET_KEY = secret_key
        self.ACCESS_KEY = access_key
        self.UTC_GMT_FORMAT = '%a, %d %b %Y %H:%M:%S GMT'

    def format_bytes(slef, bytes_num):
        '''
        格式化 字节数
        :param n:
        :return:
        '''
        unit = ('K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y')
        sinfo = {}
        for inx, s in enumerate(unit):
            sinfo[s] = 1 << (inx + 1) * 10
        for s in reversed(unit):
            if bytes_num >= sinfo[s]:
                value = float(bytes_num) / sinfo[s]
                return '{0:.2f}{1}'.format(value, s)
        return "{0}B".format(bytes_num)

    def get_common_header(self):
        return {'User-Agent': "JSS-SDK-PYTHON/1.0.0",
                'Date': self.get_utc_gmt_now(),
                'Expect': "", 'Signature': ""}


    def get_utc_gmt_now(self):
        return datetime.datetime.utcnow().strftime(self.UTC_GMT_FORMAT)

    def list_buckets(self):
        '''
        获取应用里所有的bucket 列表
        :return:        bucket 列表
        '''
        headers = self.get_common_header()
        oss_path = '/'
        headers['Authorization'] = self.make_sign(oss_path)

        uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        result = requests.request(method="get", url=uri, headers=headers, timeout=5)
        json_result = json.loads(result.content)

        if result.status_code != 200:
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        for r in json_result['Buckets']:
            r['utc_mtime'] = datetime.datetime.strptime(r['CreationDate'], self.UTC_GMT_FORMAT)

        return json_result['Buckets']

    def created_bucket(self, bucket):
        '''
        创建一个bucket
        :param bucket:
        :return:
        '''
        headers = self.get_common_header()

        oss_path = '/{0}'.format(bucket)
        headers['Authorization'] = self.make_sign(oss_path, 'PUT')

        uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        result = requests.put(uri, headers=headers)
        if result.status_code not in (200, 201):
            json_result = json.loads(result.content)
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        return result.status_code in (200, 201)

    def del_bucket(self, bucket):
        '''
        删除一个 bucket  这里注意 bucket 不为空的时候是无法删除的
        :param bucket:
        :return:
        '''
        headers = self.get_common_header()
        oss_path = '/{0}'.format(bucket)
        headers['Authorization'] = self.make_sign(oss_path, 'DELETE')

        uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        result = requests.delete(url=uri, headers=headers, timeout=2)

        if result.status_code not in (200, 204):
            json_result = json.loads(result.content)
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        return result.status_code in (200, 204)

    def list_bucket_files(self, bucket, marker='', max_keys=1000):
        '''
        列出bucket 里的对象 marker 和 max_keys组合起来实现翻页
        如果 返回结果里的 'HasNext' 为 True 表示还有下一页

        :param bucket:   指定的buket
        :param marker:   上一页列表里最后一个对象的key
        :param max_keys:  每夜最多返回多少个 默认1000
        :return:
        '''
        headers = self.get_common_header()
        oss_path = '/{0}'.format(bucket)
        headers['Authorization'] = self.make_sign(oss_path)

        if marker:
            uri = '{0}{1}?marker={2}&max-keys={3}'.format(self.ROOT_PAHT, oss_path, marker, min(max_keys, 1000))
        else:
            uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        result = requests.request(method="get", url=uri, headers=headers, timeout=5)
        json_result = json.loads(result.content)

        if result.status_code != 200:
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        for r in json_result['Contents']:
            r['utc_mtime'] = datetime.datetime.strptime(r['LastModified'], self.UTC_GMT_FORMAT)
            r['file_size'] = self.format_bytes(r['Size'])

        return json_result


    def get_obj(self, bucket="nlp.resources", key="synonym.synonym.txt", local_file=None):
        '''
        获取 制定 bucket 里的 指定key 注意这里的 result.content 是原始文件utf-8字节码
        :param bucket:          远程bucket对象名
        :param key:             对象key
        :param local_file:      本地文件
        :return:                boolean 或 对象字节内容
        '''
        headers = self.get_common_header()
        oss_path = '/{0}/{1}'.format(bucket, key)
        headers['Authorization'] = self.make_sign(oss_path)

        uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        result = requests.request(method="get", url=uri, headers=headers, timeout=2)
        if result.status_code != 200:
            json_result = json.loads(result.content)
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        if local_file is not None:
            with open(local_file, 'wb') as outfile:
                outfile.write(result.content)
            return True

        return result.content

    def put_obj(self, bucket, key=None, local_file=''):
        '''
        上传一个文件对象到制定的bucket
        :param bucket:      远程bucket对象名
        :param key:         只能包含字母、数字、中文、”/”、”.”、”-”、”_” 组成 不能‘/’开头 长度在 1-100字符之间
        :param local_file:  本地要上传的文件
        :return:            boolean
        '''
        assert(os.path.exists(local_file))
        if key is None:
            key = os.path.basename(local_file)

        headers = self.get_common_header()

        oss_path = '/{0}/{1}'.format(bucket, key)
        # 不知道为什么 这个地方不能直接用真是的mimetype 比喻xlsx 会失败 强制octet-stream 反而成功
        # content_type = self.get_mimetypes(local_file)
        content_type = 'application/octet-stream'
        content_md5 = self.get_file_md5(local_file)
        headers['Content-Length'] = "{0}".format(os.stat(local_file)[stat.ST_SIZE])
        headers['Authorization'] = self.make_sign(oss_path, 'PUT', content_md5, content_type)
        headers['Content-MD5'] = content_md5
        headers['Content-Type'] = content_type

        uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        fdata = ""
        with open(local_file, 'rb') as f:
            fdata = f.read()

        result = requests.put(uri, data=fdata, headers=headers)

        if result.status_code != 200:
            json_result = json.loads(result.content)
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        return result.status_code == 200


    def del_obj(self, bucket, key):
        '''
        删除 bucket 对象里的 key 对象
        :param bucket:  远程bucket
        :param key:     远程对象的key
        :return:        Boolean
        '''
        headers = self.get_common_header()
        oss_path = '/{0}/{1}'.format(bucket, key)
        headers['Authorization'] = self.make_sign(oss_path, 'DELETE')

        uri = '{0}{1}'.format(self.ROOT_PAHT, oss_path)
        result = requests.delete(url=uri, headers=headers, timeout=2)

        if result.status_code not in (200, 204):
            json_result = json.loads(result.content)
            if 'code' in json_result and 'message' in json_result:
                raise Exception("{0}: {1}".format(json_result['code'], json_result['message']))

        return result.status_code in (200, 204)

    def make_sign(self, oss_path, method="GET", cmd5="", ctype=""):
        '''
        HMAC-SHA1 --> http://www.ietf.org/rfc/rfc2104.txt
        :param oss_path:    远程oss path
        :param method:      http操作方法
        :param cmd5:        如果是上传 上传文件对象的md5
        :param ctype:       文件的minitype  支持不完善 都用 application/octet-stream 用真实文件 minetypes 反而会失败
        :return:
        '''
        string_to_sign = "{0}\n{1}\n{2}\n{3}\n{4}".format(
            method, cmd5, ctype,
            self.get_utc_gmt_now(),
            oss_path
        )
        if ISPY3:
            signature = base64.b64encode(hmac.new(self.SECRET_KEY.encode('utf-8'), string_to_sign.encode('utf-8'), hashlib.sha1).digest())
            return "jingdong {0}:{1}".format(self.ACCESS_KEY, signature.decode('utf-8'))

        signature = base64.b64encode(hmac.new(self.SECRET_KEY, string_to_sign, hashlib.sha1).digest())
        return "jingdong {0}:{1}".format(self.ACCESS_KEY, signature)

    def get_file_md5(self, local_file):
        '''
        本地文件
        :param local_file:
        :return:
        '''
        if not os.path.exists(local_file):
            raise Exception('file {0} not exists'.format(local_file))
        md5str = ""
        read_str = ""
        try:
            md5func = hashlib.md5()
            with open(local_file, 'rb') as file_obj:
                while True:
                    read_str = file_obj.read(8096)
                    if not read_str:
                        break
                    md5func.update(read_str)

            md5str = md5func.hexdigest()
        except:
            pass
        return md5str


    def get_mimetypes(self, local_file):
        '''
        京东oss对 Content-Type 支持不完善 都用 application/octet-stream 用真实文件 minetypes 反而会失败
        :param local_file:
        :return:
        '''
        ext_custom_mime = {
            "js": "application/javascript",
            "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "xltx": "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
            "potx": "application/vnd.openxmlformats-officedocument.presentationml.template",
            "ppsx": "application/vnd.openxmlformats-officedocument.presentationml.slideshow",
            "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "sldx": "application/vnd.openxmlformats-officedocument.presentationml.slide",
            "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "dotx": "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
            "xlam": "application/vnd.ms-excel.addin.macroEnabled.12",
            "xlsb": "application/vnd.ms-excel.sheet.binary.macroEnabled.12",
            "apk": "application/vnd.android.package-archive",
        }
        try:
            name = os.path.basename(local_file)
            suffix = name.rsplit('.', 1)[-1].lower()
            if suffix in ext_custom_mime:
                return ext_custom_mime[suffix]

            import mimetypes
            mimetypes.init()
            return mimetypes.types_map[".{0}".format(suffix)]
        except Exception:
            return "application/octet-stream"
        return "application/octet-stream"

    def get_bucket_all_key(self, bucket):
        '''
        如果一个bucket 里的数据 > 1000 自动判断翻页 返回所有的key信息
        :param bucket:
        :return:
        '''
        has_next = True
        marker = ''

        all_key_list = []

        i = 0
        while has_next:
            r = self.list_bucket_files(bucket, marker)
            for x in r['Contents']:
                all_key_list.append(x)
            has_next = r['HasNext']
            if has_next:
                i += 1
                marker = r['Contents'][-1]['Key']
        return all_key_list

def main(argv):
    access_key = '50ksloUitRjTNwzr'
    secret_key = '8GguhY7JVRw5ZSNwhQ2si41otqNV8Xa7XLZHBU8W'
    violin_bucket = 'violin-lib'
    option = ''
    localfile = ''
    remotefile = ''

    opts, args = getopt.getopt(argv, "ho:l:r:", ["option=", "localfile=", "remotefile="])

    for opt, arg in opts:
        if opt == "-h":
            print('argv -o <option> -l <localfile> -r <remotefile>')
            sys.exit(2)
        elif opt in ("-o", "-option"):
            option = arg
        elif opt in ("-l", "-localfile"):
            localfile = arg
        elif opt in ("-r", "-remotefile"):
            remotefile = arg

    T = OSS_Client(secret_key, access_key)

    if option == 'get':
        print(T.get_obj(violin_bucket,remotefile,localfile))
    elif option == 'put':
        print(T.put_obj(violin_bucket,remotefile,localfile))
    else:
        print('option must in ( put、get )')
        sys.exit(2)


if __name__ == "__main__":
    main(sys.argv[1:])