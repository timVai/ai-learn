#!/usr/bin/env bash

set -e

APP_HOME="$(cd $(dirname $0)/..; pwd -P)"
docker build -t ubuntu/ubuntu16.04-violin-cpu:violin-20190104 -f Dockerfile_ubuntu .
