
# **CLion远程调试ViolinPlugin程序** 

## 1 项目目录

```
bin：编译生成的可执行文件目录
build：编译目录
conf：配置文件目录
data：数据目录
doc：文档目录
docker：镜像容器管理
lib：编译的库文件目录
src：源码目录
    -apps：可执行程序源码
    -include：对外发布的头文件目录
    -modules：开发模块目录
       -log：日志模块
       -pytorch：pytorch处理模块
       -tensorflow：TensorFlow处理模块
       -utils：工具类
test：测试程序目录
tools：编译和测试工具
     -build.sh：编译程序
     -test.sh：测试程序
```



依赖目录：

tensorflow lib：/App/Violin/dependencies/tensorflow/lib

tensorflow include：/App/Violin/dependencies/tensorflow/include



## 2 模型预测

目前可支持的预测模型：

| 框架       | 模型格式   | 扩展名      | 备注                                      |
| ---------- | ---------- | ----------- | ----------------------------------------- |
| tensorflow | checkpoint | 目录        |                                           |
|            | protobuf   | .pb         | saved_model.pb                            |
| caffe2     | protobuf   | .pb         | 内容与TF不同(init_net.pb和predict_net.pb) |
|            | onnx       | .onnx       |                                           |
| pytorh     | pickle     | .pt或者.pth | torch.save实际是pickle序列化              |
|            | 未知       | .pt         | torch.jit.ScriptModule是torch序列化       |
|            | onnx       | .onnx       |                                           |
| onnx       | onnx       | .onnx       |                                           |
| cntk       | onnx       | .onnx       |                                           |
| mxnet      | onnx       | .onnx       |                                           |



## 3  Docker容器准备

建议将docker的内存调整到4G+，swap调整到3G+，否则可能出现gcc编译异常



![config docker for mac](./pic/docker_config.jpg)

```
#构建镜像：需要执行很久，大约1小时，文件约4G大小
sh docker/docker_ubuntu.sh build
or sh docker/docker_centos.sh build


#启动容器：
sh docker/docker_ubuntu.sh start
or sh docker/docker_centos.sh start

#基于基础镜像构建线上环境镜像：
sh appdocker/appdocker.sh

```



## 4   Cilon配置

### 4.1    版本要求

![](./pic/version.png)



### 4.2    工具链配置

![](./pic/toolchain.png)



用户/密码：root/root@123 



### 4.3    Cmake配置

![](./pic/cmake.png)



### 4.4    发布配置



![](./pic/deploy.png)





![](./pic/deploy_path.png)



### 4.5    加载项目

![](./pic/load_cmake.png)



![](./pic/load_log.png)



### 4.6    运行调试

![](./pic/debug.png)

