#!/usr/bin/env bash

set -e

APP_HOME="$(cd $(dirname $0)/..; pwd -P)"
cd ${APP_HOME}/../
docker build -t ubuntu/ubuntu16.04-violin-cpu:violin-20190104 -f ViolinPlugins/appdocker/Dockerfile_ubuntu .
cd -
