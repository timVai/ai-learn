#!/usr/bin/env bash
# docker.sh
cpath=`dirname $0`
script_path=`cd ${cpath};pwd`;
cd ${script_path}


action=$1

if [ "$action" = "into" ]; then
    docker exec -it clion_docker_dev_centos /bin/bash
elif [ "$action" = "build" ]; then
    docker-compose -f docker-compose-centos.yml build
elif [ "$action" = "start" ]; then
    docker-compose -f docker-compose-centos.yml up -d
elif [ "$action" = "stop" ]; then
    docker-compose -f docker-compose-centos.yml down
elif [ "$action" = "debug" ]; then
    docker-compose exec clion_docker_dev_centos sh -c "gdbserver :7777 bin/test1"
else
    echo "please input the right para [into|build|start|stop|debug]"
fi
