#include "api/violin_cgo.h"
#include "api/ViolinInner.pb.h"

using namespace std;

int main() {

    string model_name = "wx+b";
    string model_version = "1";

    Request request = Request();
    Response response;
    Model *model = request.mutable_model();
    ModelStatus modelStatus;

    model->set_type(ModelType::PYTORCH);
    model->set_version(model_version);
    model->set_name(model_name);
    model->set_path("../data/model/" + model_name + "/" + model_version + "/LR_20190118_C.pt");
    request.mutable_model();


    Req req;
    Rsp *rsp;
    void *buffer;

    /*---------load--------*/
    req.len = (int) model->ByteSizeLong();
    buffer = malloc(model->ByteSizeLong());
    model->SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    load(req, (void **) &rsp);

    modelStatus.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "load rsp_msg --->>:" << modelStatus.msg() << endl;
    freeRsp(rsp);
    delete buffer;
    if (modelStatus.mode_status() != 0) {
        return 1;
    }

    /*---------predict--------*/
    auto input_batch = request.mutable_input_tensor();
    auto innerTensor = InnerTensor();
    string name = "input_x";
    request.add_x_name(name);
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::float32);
    auto tensor_value_a = innerTensor.add_tensor_values();
    tensor_value_a->add_items(4);
    input_batch->insert({name, innerTensor});

    name = "y_wx+b";
    request.add_y_name(name);

    req.len = (int) request.ByteSizeLong();
    buffer = malloc(request.ByteSizeLong());
    request.SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    predict(req, (void **) &rsp);

    response.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "predict rsp_msg --->>:" << response.msg() << endl;

    freeRsp(rsp);
    delete buffer;
    if (response.rsp_code() != 0) {
        return 1;
    }

    auto outPutinnerTensorMap = response.output_tensor();

    for (int k = 0; k < request.y_name_size(); ++k) {

        name = request.y_name(k);
        auto outPutInnerTensor = outPutinnerTensorMap[name];

        //循环数据
        for (int i = 0; i < outPutInnerTensor.tensor_values_size(); i++) {

            auto output = outPutInnerTensor.tensor_values(i);
            int window = 1;

            for (int d = 0; d < outPutInnerTensor.dims_size(); d++) {
                cout << "index:" << i << ",dim: " << outPutInnerTensor.dims(d) << endl;
                window *= outPutInnerTensor.dims(d);
            }

            cout << "index:" << i << ",value:";
            for (int j = 0; j < window; j++) {
                auto output_tensor_value = output.items(j);
                cout << output_tensor_value << " ";
            }
            cout << endl;
        }
    }

    /*---------unload--------*/
    req.len = (int) model->ByteSizeLong();
    buffer = malloc(model->ByteSizeLong());
    model->SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    unload(req, (void **) &rsp);

    modelStatus.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "unload rsp_msg --->>:" << modelStatus.msg() << endl;
    freeRsp(rsp);
    delete buffer;
    if (modelStatus.mode_status() != 0) {
        return 1;
    }

    return 0;
}
