
#include "tensorflow/core/public/session.h"
#include "tensorflow/core/framework/tensor.h"
#include "tensorflow/core/framework/types.pb.h"

using namespace std;
using namespace tensorflow;

template<typename T>
Tensor AsTensor(gtl::ArraySlice<T> vals) {
    Tensor ret(DataTypeToEnum<T>::value, {static_cast<int64>(vals.size())});
    std::copy_n(vals.data(), vals.size(), ret.flat<T>().data());
    return ret;
}


int main() {

    Session *session;
    Status status = NewSession(SessionOptions(), &session);
    if (!status.ok()) {
        std::cerr << status.ToString() << std::endl;
        return 1;
    } else {
        std::cout << "Session created successfully" << std::endl;
    }

    // Load the protobuf graph
    GraphDef graph_def;
    std::string graph_path = "../data/model/banned/1/BilstmCrf_cmtForbid.pb";
    status = ReadBinaryProto(Env::Default(), graph_path, &graph_def);
    if (!status.ok()) {
        std::cerr << status.ToString() << std::endl;
        return 1;
    } else {
        std::cout << "Load graph protobuf successfully" << std::endl;
    }

    int node_count = graph_def.node_size();
    for (int i = 0; i < node_count; i++) {
        auto n = graph_def.node(i);
        cout << "Names : " << n.name() << endl;
    }

    // Add the graph to the session
    status = session->Create(graph_def);
    if (!status.ok()) {
        std::cerr << status.ToString() << std::endl;
        return 1;
    } else {
        std::cout << "Add graph to session successfully" << std::endl;
    }


    //-------------------
    std::vector<std::pair<string, tensorflow::Tensor>> inputs;
    std::vector<tensorflow::Tensor> outputs;

    int x[2][200] = {{37, 111, 1904, 438, 50, 12, 70, 942, 45, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                     {37, 111, 1904, 438, 50, 12, 70, 942, 45, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    };

    int padding_length = sizeof(x[0]) / sizeof(int);
    int batch_size = sizeof(x) / sizeof(x[0]);
    tensorflow::Tensor X(tensorflow::DT_INT32, tensorflow::TensorShape({batch_size, padding_length}));
    auto input_tensor_mapped = X.tensor<int, 2>();
    TensorShape shape = X.shape();
    for (int i = 0; i < shape.dims(); i++) {
        cout << "shape.dims:" << shape.dim_size(i) << endl;
    }


    for (int i = 0; i < batch_size; i++) {
        cout << "input[" << i << "]=[";
        for (int j = 0; j < padding_length; j++) {
            if (j == padding_length - 1) {
                cout << x[i][j] << "";
            } else {
                cout << x[i][j] << ",";
            }
            input_tensor_mapped(i, j) = x[i][j];
        }
        cout << "]" << endl;
    }

    cout << X.shape() << endl;

    inputs.push_back(std::pair<std::string, Tensor>("word_ids", X));

    cout << "X1.DebugString"  << X.DebugString() << endl;

    tensorflow::Tensor X2(tensorflow::DT_INT32, tensorflow::TensorShape({batch_size}));
    auto input_tensor_mapped2 = X2.tensor<int, 1>();
    for (int j = 0; j < batch_size; j++) {
        input_tensor_mapped2(j) = sizeof(x[j]) / sizeof(int);;
        cout << "lengths[" << j << "]=" << input_tensor_mapped2(j) << endl;

    }
    cout << "X2.DebugString" << X2.shape() << endl;

    inputs.push_back(std::pair<std::string, Tensor>("sequence_lengths", X2));

    cout << X2.DebugString() << endl;


    Tensor t2(DT_FLOAT, TensorShape());
    t2.scalar<float>()() = 1.0;
//    inputs.push_back(std::pair<std::string, Tensor>("dropout", t2));

    tensorflow::Tensor X3(tensorflow::DT_FLOAT, tensorflow::TensorShape({1}));
    auto input_tensor_mapped3 = X3.tensor<float, 1>();
    input_tensor_mapped3(0) = 1.0;
//    cout << "X3[" <<   "]=" << input_tensor_mapped3(0) << endl;
    inputs.push_back(std::pair<std::string, Tensor>("dropout", X3));

    cout << "t2.DebugString" << t2.DebugString() << endl;

    for (int i = 0; i < inputs.size(); i++) {
        cout << inputs[i].first << "-------------------------------end:" << inputs[i].second.DebugString() << endl;
    }


    status = session->Run(inputs, {"loss_op/decode/cond/ReverseSequence_1"}, {}, &outputs);

    if (!status.ok()) {
        std::cerr << status.ToString() << std::endl;
        return 1;
    } else {
        std::cout << "Run session successfully" << std::endl;
    }

    cout << "outputs.size:" << outputs.size() << endl;
    cout << "outputs.shape:" << outputs[0].shape() << endl;

    auto Item = outputs[0].shaped<int, 2>({batch_size, padding_length}); // { 1, 2 } -> One sample+2 label classes
    for (int i = 0; i < batch_size; i++) {
        cout << "output[" << i << "]=[";

        for (int j = 0; j < padding_length; j++) {
            if (j == padding_length - 1) {
                cout << Item(i, j) << "";
            } else {
                cout << Item(i, j) << ",";
            }
        }
        cout << "]";
        cout << endl;

    }

    return 0;
}
