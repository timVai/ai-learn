#include <torch/script.h> // One-stop header.
#include <torch/torch.h>
#include "c10/util/ArrayRef.h"

#include <iostream>
#include <memory>
#include <vector>

using namespace std;

int main(int argc, const char *argv[]) {

    std::cout << "Hello, World pyTorch !" << std::endl;

    string model_name = "wx+b";
    string model_version = "1";

    string file_name = "../data/model/" + model_name + "/" + model_version + "/LR_20190118_C.pt";

    torch::TensorOptions tensorOptions = torch::device(torch::kCPU).is_variable(true);

    std::shared_ptr<torch::jit::script::Module> module = torch::jit::load(file_name);

    std::vector<torch::jit::IValue> inputs;

    float x = 1.0;
    at::Tensor tensor = torch::tensor(x);
    tensor = tensor.to(at::kFloat);
    inputs.push_back(tensor);
    auto output = module->forward(inputs).toTensor();
    cout << "result1: " << output[0].item().toDouble() << std::endl;

    //---------------------------------------------------------------

    std::vector<torch::jit::IValue> inputs2;
    float *data = new float[1]();
    data[0] = 1;
    torch::Tensor input_id = torch::from_blob(data, {1}, tensorOptions);
    input_id = input_id.to(at::kFloat);
    inputs2.push_back(input_id);

    auto output2 = module->forward(inputs2).toTensor();
    cout << "result2: " << output2[0].item().toDouble() << std::endl;

}
