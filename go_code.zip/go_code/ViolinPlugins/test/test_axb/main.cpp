#include "api/model_predict.h"
#include <gtest/gtest.h>

using namespace std;

class TestA : public testing::Test {

public:
    virtual void SetUp() {
        /*---------load--------*/
        string model_name = "a*b";
        string model_version = "1";
        model->set_type(ModelType::TENSORFLOW);
        model->set_version(model_version);
        model->set_name(model_name);
        model->set_path("../data/model/" + model_name + "/" + model_version + "/graph.pb");
        int status = load(model, &modelStatus);
        if (status != 0) {
            return;
        }
    }

    virtual void TearDown() {
        /*---------unload--------*/
        int status = unload(model, &modelStatus);
        if (status != 0) {
            return;
        }
    }

    Model *model = new Model();
    ModelStatus modelStatus;
    Request *request = new Request();;
    Response *response;

};

TEST_F(TestA, PushBack) {

    /*---------predict--------*/

    request->set_allocated_model(model);

    auto input_batch = request->mutable_input_tensor();
    auto innerTensor = InnerTensor();
    string name = "a";
    request->add_x_name(name);
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::float16);
    innerTensor.add_tensor_values()->add_items(3);
    input_batch->insert({name, innerTensor});

    name = "b";
    request->add_x_name(name);
    innerTensor = InnerTensor();
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::float16);
    innerTensor.add_tensor_values()->add_items(4);
    input_batch->insert({name, innerTensor});

    name = "c";
    request->add_y_name(name);

    Response *response = new Response();

    int status = predict(request, response);
    if (status != 0) {
        return;
    }

    auto outPutinnerTensorMap = response->output_tensor();
    auto outPutInnerTensor = outPutinnerTensorMap[name];
    ASSERT_EQ(outPutInnerTensor.tensor_values(0).items(0), 12);
    cout << "rsp " << outPutInnerTensor.tensor_values(0).items(0) << endl;

}
