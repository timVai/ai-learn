#include "api/violin_cgo.h"
#include "api/ViolinInner.pb.h"

using namespace std;

int main() {

    //one input_x1:[1,200],input_x2:[1];output:[1,200]
    //two input_x1:[2,200],input_x2:[2];output:[2,200]

    string model_name = "banned";
    string model_version = "3";

    Request request = Request();
    Response response;
    Model *model = request.mutable_model();
    ModelStatus modelStatus;

    model->set_type(ModelType::TENSORFLOW);
    model->set_version(model_version);
    model->set_name(model_name);
    model->set_path("../data/model/" + model_name + "/" + model_version + "/BilstmCrf_cmtForbid.pb");
    request.mutable_model();

    Req req;
    Rsp *rsp;
    void *buffer;

    /*---------load--------*/
    req.len = (int) model->ByteSizeLong();
    buffer = malloc(model->ByteSizeLong());
    model->SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    load(req, (void **) &rsp);

    modelStatus.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "load rsp_msg --->>:" << modelStatus.msg() << endl;
    freeRsp(rsp);
    delete buffer;
    if (modelStatus.mode_status() != 0) {
        return 1;
    }

    /*---------predict--------*/
    auto input_batch = request.mutable_input_tensor();
    auto innerTensor = InnerTensor();
    string name = "word_ids";
    request.add_x_name(name);
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::int32);
    innerTensor.add_dims(200);
    auto tensor_value_a = innerTensor.add_tensor_values();
    for (int i = 0; i < 200; i++) {
        tensor_value_a->add_items(i);
    }
//    tensor_value_a = innerTensor.add_tensor_values();
//    for (int i = 0; i < 200; i++) {
//        tensor_value_a->add_items(i);
//    }
    input_batch->insert({name, innerTensor});

    innerTensor = InnerTensor();
    name = "sequence_lengths";
    request.add_x_name(name);
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::int32);
    innerTensor.add_dims(1);
    tensor_value_a = innerTensor.add_tensor_values();
    tensor_value_a->add_items(200);
//    tensor_value_a = innerTensor.add_tensor_values();
//    tensor_value_a->add_items(200);
    input_batch->insert({name, innerTensor});

    name = "loss_op/decode/cond/ReverseSequence_1";
    request.add_y_name(name);

    req.len = (int) request.ByteSizeLong();
    buffer = malloc(request.ByteSizeLong());
    request.SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    predict(req, (void **) &rsp);

    response.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "predict rsp_msg --->>:" << response.msg() << endl;

    freeRsp(rsp);
    delete buffer;
    if (response.rsp_code() != 0) {
        return 1;
    }

    auto outPutinnerTensorMap = response.output_tensor();
    cout << "y_name size:" << response.y_name_size() << endl;
    cout << "y_name:" << response.y_name(0) << endl;
    auto outPutInnerTensor = outPutinnerTensorMap[name];
    cout << "y_name dims_size:" << outPutInnerTensor.dims_size() << endl;

    //循环数据
    for (int i = 0; i < outPutInnerTensor.tensor_values_size(); i++) {

        auto output = outPutInnerTensor.tensor_values(i);
        int window = 1;

        for (int d = 1; d < outPutInnerTensor.dims_size(); d++) {
            cout << "output index:" << i << ",dim: " << outPutInnerTensor.dims(d) << endl;
            window *= outPutInnerTensor.dims(d);
        }

        cout << "output value:";
        for (int j = 0; j < window; j++) {
            auto output_tensor_value = output.items(j);
            cout << output_tensor_value << " ";
        }
        cout << endl;

    }

    /*---------unload--------*/
    req.len = (int) model->ByteSizeLong();
    buffer = malloc(model->ByteSizeLong());
    model->SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    unload(req, (void **) &rsp);

    modelStatus.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "unload rsp_msg --->>:" << modelStatus.msg() << endl;
    freeRsp(rsp);
    delete buffer;
    if (modelStatus.mode_status() != 0) {
        return 1;
    }

    return 0;
}
