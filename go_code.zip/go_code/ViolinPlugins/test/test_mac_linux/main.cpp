#include <iostream>

int main() {

    std::cout << "Hello, this is from ";

#ifdef __linux__
    std::cout << "Linux !" << std::endl;
#elif __APPLE__
    std::cout << "Mac !"<<std::endl;
#endif

    return 0;
}
