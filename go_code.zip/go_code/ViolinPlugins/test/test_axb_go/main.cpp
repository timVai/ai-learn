#include "api/violin_cgo.h"
#include "api/ViolinInner.pb.h"

using namespace std;

int main() {

    //one input_x1:[0],input_x2:[0];output:[0]
    //two input_x1:[2],input_x2:[2];output:[2]

    string model_name = "a*b";
    string model_version = "1";

    Request request = Request();
    Response response;
    Model *model = request.mutable_model();
    ModelStatus modelStatus;

    model->set_type(ModelType::TENSORFLOW);
    model->set_version(model_version);
    model->set_name(model_name);
    model->set_path("../data/model/" + model_name + "/" + model_version + "/graph.pb");

    Req req;
    Rsp *rsp;
    void *buffer;

    /*---------load--------*/
    req.len = (int) model->ByteSizeLong();
    buffer = malloc(model->ByteSizeLong());
    model->SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    load(req, (void **) &rsp);

    modelStatus.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "load rsp_msg --->>:" << modelStatus.msg() << endl;
    if (modelStatus.mode_status() != 0) {
        return 1;
    }


    /*---------predict--------*/
    auto input_batch = request.mutable_input_tensor();
    auto innerTensor = InnerTensor();
    string name = "a";
    request.add_x_name(name);
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::float16);
    auto tensor_value_a = innerTensor.add_tensor_values();
    tensor_value_a->add_items(3.1);
    tensor_value_a = innerTensor.add_tensor_values();
    tensor_value_a->add_items(4.1);
    input_batch->insert({name, innerTensor});

    name = "b";
    innerTensor = InnerTensor();
    request.add_x_name(name);
    innerTensor.set_tensor_name(name);
    innerTensor.set_dtype(DType::float16);
    tensor_value_a = innerTensor.add_tensor_values();
    tensor_value_a->add_items(4.0);
    tensor_value_a = innerTensor.add_tensor_values();
    tensor_value_a->add_items(5.0);
    input_batch->insert({name, innerTensor});

    name = "c";
    request.add_y_name(name);

    req.len = (int) request.ByteSizeLong();
    buffer = malloc(request.ByteSizeLong());
    request.SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    predict(req, (void **) &rsp);

    response.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "predict rsp_msg --->>:" << response.msg() << endl;
    if (response.rsp_code() != 0) {
        return 1;
    }

    auto outPutinnerTensorMap = response.output_tensor();
    auto outPutInnerTensor = outPutinnerTensorMap[name];
    for (int i = 0; i < outPutInnerTensor.tensor_values_size(); ++i) {
        cout << "rsp c=" << outPutInnerTensor.tensor_values(i).items(0) << endl;
    }

    /*---------unload--------*/
    req.len = (int) model->ByteSizeLong();
    buffer = malloc(model->ByteSizeLong());
    model->SerializeToArray(buffer, req.len);
    req.in_ptr = (unsigned char *) buffer;

    unload(req, (void **) &rsp);

    response.ParseFromArray(rsp->out_ptr, rsp->len);
    cout << "unload rsp_msg --->>:" << response.msg() << endl;

    cout << "load rsp_msg --->>:" << modelStatus.msg() << endl;
    if (modelStatus.mode_status() != 0) {
        return 1;
    }

    return 0;
}
