/**
  * CacheModels.h
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include "iostream"
#include "map"

#include "tensorflow/core/platform/env.h"
#include "tensorflow/core/public/session.h"

using namespace std;
using namespace tensorflow;

static map<string, Session *> IntMap;

class TensorflowCacheModels {
public:
    TensorflowCacheModels(void);

    virtual ~TensorflowCacheModels(void);

public:
    static void add(string key, Session* value);

    static Session *get(string key);

    static void remove(string key);

};
