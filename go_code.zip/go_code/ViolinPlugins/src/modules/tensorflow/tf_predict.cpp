/**
  * tf_predict.h
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

//#include "tf_predict.h"
#include "api/model_predict.h"
#include "log/AppLog.h"
#include "tensorflow_cache_models.h"
#include <vector>

#include "iostream"
#include "tensorflow/core/framework/types.pb.h"

using namespace std;
using namespace tensorflow;

int load(Model *model, ModelStatus *modelStatus) {

    string msg = "";
    logInfo("ready tensorflow load");

    int rsp_code = unload(model, modelStatus);
    if (rsp_code != 0) {
        msg = "unload graph protobuf error code " + to_string(rsp_code);
        logError(msg);
        modelStatus->set_msg(msg);
        return 1;
    }

    GraphDef graph_def;
    Status status;
    std::string graph_path = model->path();

    if (graph_path == "") {
        msg = "model->path is null";
        logError(msg);
        modelStatus->set_msg(msg);
        return 1;
    }

    status = ReadBinaryProto(Env::Default(), graph_path, &graph_def);
    if (!status.ok()) {
        msg = "load graph protobuf error code " + status.ToString();
        logError(msg);
        modelStatus->set_msg(msg);
        return 1;
    }

    Session *session;
    status = NewSession(SessionOptions(), &session);
    if (!status.ok()) {
        msg = "load graph NewSession error " + status.ToString();
        logError(msg);
        modelStatus->set_msg(msg);
        return 1;
    }

    logInfo("Session created successfully");

    // Add the graph to the session
    status = session->Create(graph_def);
    if (!status.ok()) {
        msg = "load graph Create error " + status.ToString();
        logError(msg);
        modelStatus->set_msg(msg);
        return 1;
    }

    logInfo("add graph to session successfully");

    TensorflowCacheModels::add(to_string(model->type()) + model->name() + model->version(), session);

    msg = "tensorflow load model successfully";
    logInfo(msg);
    modelStatus->set_mode_status(0);
    modelStatus->set_msg(msg);

    return 0;

}

void tensorValueSet(TensorProto *input_tensor_proto, TensorValue *input_tensor_value, int index, DType input_type) {
    switch (input_type) {
        case DType::float16: {
            input_tensor_proto->set_dtype(DT_FLOAT);
            input_tensor_proto->add_float_val(input_tensor_value->items(index));
            break;
        }
        case DType::float32: {
            input_tensor_proto->set_dtype(DT_FLOAT);
            input_tensor_proto->add_float_val(input_tensor_value->items(index));
            break;
        }
        case DType::float64: {
            input_tensor_proto->set_dtype(DT_FLOAT);
            input_tensor_proto->add_float_val(input_tensor_value->items(index));
            break;
        }
        case DType::int8: {
            input_tensor_proto->set_dtype(DT_INT32);
            input_tensor_proto->add_int_val((int) input_tensor_value->items(index));
            break;
        }
        case DType::int16: {
            input_tensor_proto->set_dtype(DT_INT64);
            input_tensor_proto->add_int64_val((int) input_tensor_value->items(index));
            break;
        }
        case DType::int32: {
            input_tensor_proto->set_dtype(DT_INT32);
            input_tensor_proto->add_int_val((int) input_tensor_value->items(index));
            break;
        }
        case DType::int64: {
            input_tensor_proto->set_dtype(DT_INT64);
            input_tensor_proto->add_int64_val((int) input_tensor_value->items(index));
            break;
        }
        default : {
            input_tensor_proto->set_dtype(DT_INT32);
            input_tensor_proto->add_int_val((int) input_tensor_value->items(index));
        }
    }

    return;
}

void setOutputTensorType(InnerTensor *output_inner_tensor, DataType output_type) {

    switch (output_type) {
        case DT_FLOAT: {
            output_inner_tensor->set_dtype(DType::float16);
            break;
        }
        case DT_DOUBLE: {
            output_inner_tensor->set_dtype(DType::float64);
            break;
        }
        case DT_INT8: {
            output_inner_tensor->set_dtype(DType::int8);
            break;
        }
        case DT_INT16: {
            output_inner_tensor->set_dtype(DType::int16);
            break;
        }
        case DT_INT32: {
            output_inner_tensor->set_dtype(DType::int32);
            break;
        }
        case DT_INT64: {
            output_inner_tensor->set_dtype(DType::int64);
            break;
        }
        default : {
            output_inner_tensor->set_dtype(DType::int32);
        }
    }

    return;
}

void
setOutputTensorValue(TensorValue *tensor_value, TensorProto *output_tensor_proto, int index, DataType output_type) {

    switch (output_type) {
        case DT_FLOAT: {
            auto value = output_tensor_proto->float_val(index);
            tensor_value->add_items(value);
            break;
        }
        case DT_INT32: {
            auto value = output_tensor_proto->int_val(index);
            tensor_value->add_items(value);
            break;
        }
        case DT_INT64: {
            auto value = output_tensor_proto->int64_val(index);
            tensor_value->add_items(value);
            break;
        }
        default : {
            auto value = output_tensor_proto->int_val(index);
            tensor_value->add_items(value);
        }
    }

    return;
}

int predict(Request *request, Response *response) {

    string msg = "";
    Status status;
    Model model = request->model();
    Session *session = TensorflowCacheModels::get(to_string(model.type()) + model.name() + model.version());

    if (request->x_name_size() == 0) {
        msg = "x_name is null";
        logError(msg);
        response->set_msg(msg);
        return 1;
    }

    if (request->y_name_size() == 0) {
        msg = "y_name is null";
        logError(msg);
        response->set_msg(msg);
        return 1;
    }

    std::vector<std::pair<string, tensorflow::Tensor>> inputs;
    std::vector<string> output_tensor_names;
    int all_batch_size = 1;

    //循环tensor
    for (int i = 0; i < request->x_name_size(); i++) {

        Tensor input_tensor;
        auto input_tensor_proto = TensorProto();

        string x_name = request->x_name(i);
        if (x_name == "") {
            msg = "tensor_name is null";
            logError(msg);
            response->set_msg(msg);
            return 1;
        }

        auto input_inner_tensor_map = request->input_tensor();
        auto input_inner_tensor = input_inner_tensor_map[x_name];
        auto input_type = input_inner_tensor.dtype();
        int x_dim_size = input_inner_tensor.dims_size();

        int batch_size = input_inner_tensor.tensor_values_size();
        if (batch_size >= all_batch_size) {
            all_batch_size = batch_size;
        }

        logDebug("name=" + x_name + ",type=" + to_string(input_type) + ",dim_size=" + to_string(x_dim_size));

        int dim_data_count = 1;

        TensorShapeProto *input_tensor_shape_proto = input_tensor_proto.mutable_tensor_shape();

        //test_axb_go
        //batch_size=1,x1_dim_size=0,x2_dim_size=0,input_x1:[0],input_x2:[0];output:[0]
        //batch_size=2,x1_dim_size=1,x2_dim_size=1,input_x1:[2],input_x2:[2];output:[2]

        //test_banned_go
        //batch_size=1,x1_dim_size=2,x2_dim_size=2,input_x1:[1,200],input_x2:[1,1];output:[1,200]
        //batch_size=2,x1_dim_size=2,x2_dim_size=2,input_x1:[2,200],input_x2:[2,1];output:[2,200]

        // add batch_size to first dim
        input_tensor_shape_proto->add_dim()->set_size(all_batch_size);
        for (int d = 0; d < x_dim_size; d++) {
            input_tensor_shape_proto->add_dim()->set_size(input_inner_tensor.dims(d));
            dim_data_count *= input_inner_tensor.dims(d);
        }

        //循环数据
        for (int c = 0; c < batch_size; c++) {

            auto input_tensor_value = input_inner_tensor.tensor_values(c);
            int tensor_value_size = input_tensor_value.items_size();

            //check tenorvalue dim
            if (tensor_value_size != dim_data_count) {
                msg = "tensor_name " + x_name + " tensor_value_size[" + to_string(tensor_value_size) +
                      "] != dim_data_count [" +
                      to_string(dim_data_count) + "]";
                logError(msg);
                response->set_msg(msg);
                return 1;
            }

            //循环value
            for (int j = 0; j < tensor_value_size; j++) {
                tensorValueSet(&input_tensor_proto, &input_tensor_value, j, input_type);
            }
        }

        logDebug("input " + x_name + " DebugString: " + input_tensor_proto.DebugString());

        input_tensor.FromProto(input_tensor_proto);
        inputs.push_back(std::pair<std::string, Tensor>(x_name, input_tensor));

    }

    for (int i = 0; i < request->y_name_size(); i++) {
        string name = request->y_name(i);
        output_tensor_names.push_back(name);
    }

    logDebug("prepare Run");

    // The session will initialize the outputs
    std::vector<tensorflow::Tensor> outputs;

    // Run the session, evaluating our "c" operation from the graph
    status = session->Run(inputs, output_tensor_names, {}, &outputs);
    if (!status.ok()) {
        msg = "session Run error " + status.ToString();
        logError(msg);
        response->set_msg(msg);
        return 1;
    }

    logDebug("Run predict successfully");
    logDebug("outputs.size: " + to_string(outputs.size()));
    logDebug("batch_size: " + to_string(all_batch_size));
    logDebug("y_name_size: " + to_string(request->y_name_size()));

    auto output_inner_tensor_map = response->mutable_output_tensor();

    //循环tensor
    for (int i = 0; i < request->y_name_size(); i++) {

        string output_tensor_name = request->y_name(i);
        Tensor output_tensor = outputs[i];
        auto output_tensor_proto = TensorProto();
        output_tensor.AsProtoField(&output_tensor_proto);
        TensorShape output_tensor_shape = output_tensor.shape();
        auto output_type = output_tensor.dtype();

        auto output_inner_tensor = InnerTensor();
        output_inner_tensor.set_tensor_name(output_tensor_name);
        response->add_y_name(output_tensor_name);

        logDebug(
                "y_name_index:" + to_string(i) + ",y_name:" + output_tensor_name + ",outputs: " +
                output_tensor.DebugString());

        setOutputTensorType(&output_inner_tensor, output_type);

        int window_size = 1;
        int dim_size = output_tensor_shape.dims();

        // delete batch_size from first dim
        for (int j = 1; j < dim_size; j++) {
            window_size *= output_tensor_shape.dim_size(j);
            output_inner_tensor.add_dims(output_tensor_shape.dim_size(j));
        }

        logDebug("y_name_index:" + to_string(i) + ",window_size: " + to_string(window_size));

        //循环数据
        for (int i = 0; i < all_batch_size; i++) {

            auto tensor_value = output_inner_tensor.add_tensor_values();

            int start = i * window_size;
            int end = (i + 1) * window_size;

            logDebug("batch_index:" + to_string(i) + ",start: " + to_string(start) + ",end: " + to_string(end));

            for (int c = start; c < end; c++) {
                setOutputTensorValue(tensor_value, &output_tensor_proto, c, output_type);
            }

            logDebug("batch_index:" + to_string(i) + ",y_name:" + output_tensor_name + ", tensor_items_size: " +
                     to_string(tensor_value->items_size()));

        }

        logDebug("y_name_index:" + to_string(i) + ",y_name:" + output_tensor_name + ", tensor_values_size: " +
                 to_string(output_inner_tensor.tensor_values_size()) + ",output_dim_size: " + to_string(dim_size));

        output_inner_tensor_map->insert({output_tensor_name, output_inner_tensor});

    }

    msg = "tensorflow predict successfully";
    logDebug(msg);
    response->set_msg(msg);

    return 0;
}

int unload(Model *model, ModelStatus *modelStatus) {

    string msg = "";
    Session *session = TensorflowCacheModels::get(to_string(model->type()) + model->name() + model->version());
    if (session != nullptr) {
        session->Close();
        delete session;
    }
    TensorflowCacheModels::remove(to_string(model->type()) + model->name() + model->version());

    msg = "tensorflow unLoad model successfully";
    logDebug(msg);
    modelStatus->set_msg(msg);

    return 0;
}
