/**
  * CacheModels.cpp
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include "tensorflow_cache_models.h"


void TensorflowCacheModels::add(string key, Session* value) {
    IntMap[key] = value;
}

Session *TensorflowCacheModels::get(string key) {
    return IntMap[key];
}

void TensorflowCacheModels::remove(string key) {
    IntMap.erase(key);
}


TensorflowCacheModels::TensorflowCacheModels(void) {
}


TensorflowCacheModels::~TensorflowCacheModels(void) {
}
