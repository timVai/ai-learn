/**
  * CacheModels.h
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include <map>

using namespace std;
typedef map<int, int> IntMap;

class CacheModels {
public:
    CacheModels(void);

    virtual ~CacheModels(void);

public:
    static IntMap m_staticMap;

};
