/**
  * CacheModels.cpp
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include "CacheModels.h"

pair<int, int> pairArray[] = {};

IntMap CacheModels::m_staticMap(pairArray, pairArray + sizeof(pairArray) / sizeof(pairArray[0]));

CacheModels::CacheModels(void) {
}


CacheModels::~CacheModels(void) {
}
