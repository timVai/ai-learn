/**
  * model_predict.h
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 20191/15 16:31
  * @func
  */

#include "api/model_predict.h"
#include "log/AppLog.h"
#include "iostream"
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#define random(x) (rand() % x)

using namespace std;

int load(Model *model, ModelStatus *modelStatus) {
    return 0;
}


int predict(Request *request, Response *response) {


    int all_batch_size = 1;

    //循环tensor
    for (int i = 0; i < request->x_name_size(); i++) {

        string x_name = request->x_name(i);
        if (x_name == "") {
            logError("tensor_name is null");
            return 1;
        }

        auto input_inner_tensor_map = request->input_tensor();
        auto input_inner_tensor = input_inner_tensor_map[x_name];

        int batch_size = input_inner_tensor.tensor_values_size();
        if (batch_size >= all_batch_size) {
            all_batch_size = batch_size;
        }
    }

    //循环tensor
    for (int i = 0; i < request->y_name_size(); i++) {

        string output_tensor_name = request->y_name(i);
        auto output_inner_tensor_map = response->mutable_output_tensor();
        auto output_inner_tensor = InnerTensor();
        output_inner_tensor.set_tensor_name(output_tensor_name);
        response->add_y_name(output_tensor_name);

        int window_size = 200;
        if (all_batch_size > 1) {
            output_inner_tensor.add_dims(window_size);
        }
        //循环数据
        for (int i = 0; i < all_batch_size; i++) {

            auto tensor_value = output_inner_tensor.add_tensor_values();
            for (int c = 0; c < window_size; c++) {
                tensor_value->add_items(c);
            }
        }

        output_inner_tensor_map->insert({output_tensor_name, output_inner_tensor});
    }

    srand((int) time(0));
    int size = all_batch_size * 100;
    int ran = random(size);

    //微秒级:1秒(s) = 1000 毫秒(ms) = 1,000,000 微秒(μs) = 1,000,000,000 纳秒(ns) = 1,000,000,000,000 皮秒(ps)
    if (all_batch_size > 1) {
        usleep(ran * 1000);
    }

    return 0;
}

int unload(Model *model, ModelStatus *modelStatus) {

    return 0;
}
