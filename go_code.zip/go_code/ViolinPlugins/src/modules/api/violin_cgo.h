
#ifndef VIOLIN_CGO_H
#define VIOLIN_CGO_H

#ifdef __cplusplus
// extern "C" is needed so the C++ compiler exports the symbols without name
// manging.
extern "C" {
#endif

struct Req {
    int len;
    unsigned char *in_ptr;
};

struct Rsp {
    int len;
    unsigned char *out_ptr;
};

/**
 * violin C统一接口
 * @param req
 * @param rsp
 */
void load(struct Req req, void **rsp);

void predict(struct Req req, void **rsp);

void unload(struct Req req, void **rsp);

/**
 * violin C 内存释放统一接口
 */
void freeRsp(void *rsp_ptr);

#ifdef __cplusplus
// extern "C" is needed so the C++ compiler exports the symbols without name
// manging.
}
#endif

#endif
