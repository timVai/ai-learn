#include "violin_cgo.h"
#include "ViolinInner.pb.h"
#include "model_predict.h"

using namespace std;

void ModelReturnFun(ModelStatus modelStatus, void **rsp);

void ServiceReturnFun(Response response, void **rsp);

void load(struct Req req, void **rsp) {

    int status = 0;
    ModelStatus modelStatus = ModelStatus();
    modelStatus.set_mode_status(1);

    if (req.len <= 0) {
        modelStatus.set_msg("req.len " + to_string(req.len) + " < 0");
        ModelReturnFun(modelStatus, rsp);
        return;
    }

    if (req.in_ptr == nullptr) {
        modelStatus.set_msg("req.in_ptr is null");
        ModelReturnFun(modelStatus, rsp);
        return;
    }

    Model model;
    model.ParseFromArray(req.in_ptr, req.len);

    status = load(&model, &modelStatus);
    if (status != 0) {
        ModelReturnFun(modelStatus, rsp);
        return;
    }

    modelStatus.set_mode_status(0);
    modelStatus.set_msg("ok");
    ModelReturnFun(modelStatus, rsp);
    return;

}


void predict(struct Req req, void **rsp) {

    int status = 0;
    Response response = Response();

    if (req.len <= 0) {
        response.set_rsp_code(1);
        response.set_msg("req.len " + to_string(req.len) + " < 0");
        ServiceReturnFun(response, rsp);
        return;
    }

    if (req.in_ptr == nullptr) {
        response.set_rsp_code(1);
        response.set_msg("req.in_ptr is null");
        ServiceReturnFun(response, rsp);
        return;
    }

    Request request;
    request.ParseFromArray(req.in_ptr, req.len);
    Model model = request.model();

    status = predict(&request, &response);
    if (status != 0) {
        response.set_rsp_code(1);
        response.set_msg("predict error");
        ServiceReturnFun(response, rsp);
        return;
    }

    response.set_rsp_code(0);
    response.set_msg("ok");
    ServiceReturnFun(response, rsp);

    return;

}


void unload(struct Req req, void **rsp) {

    int status = 0;
    ModelStatus modelStatus = ModelStatus();

    if (req.len <= 0) {
        modelStatus.set_mode_status(1);
        modelStatus.set_msg("req.len " + to_string(req.len) + " < 0");
        ModelReturnFun(modelStatus, rsp);
        return;
    }

    if (req.in_ptr == nullptr) {
        modelStatus.set_mode_status(1);
        modelStatus.set_msg("req.in_ptr is null");
        ModelReturnFun(modelStatus, rsp);
        return;
    }

    Model model;
    model.ParseFromArray(req.in_ptr, req.len);

    status = unload(&model, &modelStatus);
    if (status != 0) {
        modelStatus.set_mode_status(1);
        modelStatus.set_msg("load error");
        ModelReturnFun(modelStatus, rsp);
        return;
    }

    modelStatus.set_mode_status(0);
    modelStatus.set_msg("ok");
    ModelReturnFun(modelStatus, rsp);

}

void ModelReturnFun(ModelStatus modelStatus, void **rsp) {

    Rsp *rsp_ptr = (Rsp *) malloc(sizeof(Rsp));

    rsp_ptr->len = modelStatus.ByteSizeLong();
    void *buffer = malloc(rsp_ptr->len);
    modelStatus.SerializeToArray(buffer, rsp_ptr->len);
    rsp_ptr->out_ptr = (unsigned char *) buffer;
    *rsp = rsp_ptr;

}

void ServiceReturnFun(Response response, void **rsp) {

    Rsp *rsp_ptr = (Rsp *) malloc(sizeof(Rsp));

    rsp_ptr->len = response.ByteSizeLong();
    void *buffer = malloc(rsp_ptr->len);
    response.SerializeToArray(buffer, rsp_ptr->len);
    rsp_ptr->out_ptr = (unsigned char *) buffer;
    *rsp = rsp_ptr;

//for debug protobuf
#if 0
    cout << "rsp_ptr->len=" << rsp_ptr->len << endl;

    cout << "[";
    for (int i = 0; i < rsp_ptr->len; ++i) {
        printf("%d,", *(((unsigned char *) buffer) + i));
    }

    cout << "]" << endl;
    cout << "[";
    for (int i = 0; i < rsp_ptr->len; ++i) {
        cout << *(((unsigned char *) buffer) + i) << ",";
    }

    cout << "]" << endl;
    cout << endl;
#endif

}

void freeRsp(void *rsp_ptr) {
    if (rsp_ptr != nullptr) {
        Rsp *del_p = (Rsp *) rsp_ptr;
        free(del_p->out_ptr);
        free(del_p);
    }
}
