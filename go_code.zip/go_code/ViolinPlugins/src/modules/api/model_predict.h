#ifndef MODEL_PREDICT_H
#define MODEL_PREDICT_H

#include "iostream"
#include "../api/ViolinInner.pb.h"

int load(Model *model, ModelStatus *modelStatus);

int predict(Request *request, Response *response);

int unload(Model *model, ModelStatus *modelStatus);

#endif
