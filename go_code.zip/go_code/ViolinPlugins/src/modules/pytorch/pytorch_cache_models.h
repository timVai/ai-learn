/**
  * CacheModels.h
  *
  * @author <a href=mailto:lizhipeng@jd.com>lizhipeng</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include "iostream"
#include "map"
#include "torch/script.h"
//#include "log/AppLog.h"

using namespace std;

static map<string, torch::jit::script::Module*> IntMap;

class PytorchCacheModels {
public:
    PytorchCacheModels(void);

    virtual ~PytorchCacheModels(void);

public:
    static void add(string key, torch::jit::script::Module* value);

    static torch::jit::script::Module*  get(string key);

    static void remove(string key);

};
