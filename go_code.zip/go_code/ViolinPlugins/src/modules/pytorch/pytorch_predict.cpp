/**
  * pytorch_predict.cpp
  *
  * @author <a href=mailto:lizhipeng@jd.com>李志鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include "api/model_predict.h"
#include "log/AppLog.h"
#include "pytorch_cache_models.h"
#include <torch/script.h> // One-stop header.
#include <torch/torch.h>
#include "c10/util/ArrayRef.h"
#include "iostream"

//using namespace std;

int load(Model *model, ModelStatus *modelStatus) {
    string path = model->path();
    logInfo("pytorch load path: " + path);
    std::shared_ptr<torch::jit::script::Module> ml_model = torch::jit::load(path);
    if (ml_model != nullptr) {
        PytorchCacheModels::add(model->name(), ml_model.get());
        return 0;
    } else {
        return -1;
    }
}

torch::TensorOptions tensorOptionsDTypeSet(torch::TensorOptions tensorOptions, DType dType) {
    switch (dType) {
        case DType::int8:
            tensorOptions = tensorOptions.dtype(at::kInt);
            break;
        case DType::int16:
            tensorOptions = tensorOptions.dtype(at::kInt);
            break;
        case DType::int32:
            tensorOptions = tensorOptions.dtype(at::kInt);
            break;
        case DType::int64:
            tensorOptions = tensorOptions.dtype(at::kLong);
            break;
        case DType::float32:
            tensorOptions = tensorOptions.dtype(at::kFloat);
            break;
        case DType::float64:
            tensorOptions = tensorOptions.dtype(at::kDouble);
            break;
        default:
            tensorOptions = tensorOptions.dtype(at::kInt);
            break;
    }
    return tensorOptions;
}

void *tensorInit(DType dType, int data_length) {
    void *data;
    switch (dType) {
        case DType::int8:
            data = new int[data_length]();
            break;
        case DType::int16:
            data = new int[data_length]();
            break;
        case DType::int32:
            data = new int[data_length]();
            break;
        case DType::int64:
            data = new long[data_length]();
            break;
        case DType::float32:
            data = new float[data_length]();
            break;
        case DType::float64:
            data = new double[data_length]();
            break;
        default:
            data = new int[data_length]();
            break;
    }
    return data;
}

void tensorValueSet(void *data, int index, DType dType, float value) {
    switch (dType) {
        case DType::int8:
            ((int *) data)[index] = value;
            break;
        case DType::int16:
            ((int *) data)[index] = value;
            break;
        case DType::int32:
            ((int *) data)[index] = value;
            break;
        case DType::int64:
            ((long *) data)[index] = value;
            break;
        case DType::float32:
            ((float *) data)[index] = value;
            break;
        case DType::float64:
            ((double *) data)[index] = value;
            break;
        default:
            ((int *) data)[index] = value;
            break;
    }
}


void setOutputTensorValue(torch::Tensor tensor, TensorValue *tensor_value) {

    int dim = tensor.dim();
    if (dim > 0) {
        int size = tensor.size(0);
        for (int i = 0; i < size; ++i) {
            setOutputTensorValue(tensor[i], tensor_value);
        }
    } else {
        tensor_value->add_items(tensor.item<double>());
//        cout << tensor.item<double>() << endl;
    }
}

int predict(Request *request, Response *response) {

    logDebug("pytorch predict");
    Model model = request->model();

    //TODO
    cout << "model.name:" << model.name() << endl;
    auto ml_model = torch::jit::load(model.path());

    torch::TensorOptions tensorOptions = torch::device(torch::kCPU).is_variable(true);
    vector<torch::IValue> x_inputs;
    int x_name_size = request->x_name_size();

    for (int i = 0; i < x_name_size; ++i) {

        //one x_name one batch tensor
        string x_name = request->x_name(i);

        logDebug("x_name：" + x_name);

        //all input tensor  map ,the key was x_name
        auto x_tesors = request->input_tensor();
        //get the batch tensor by x_name key
        InnerTensor x_tesor_batch = x_tesors[x_name];

        int dim_length = x_tesor_batch.dims_size() + 1;
        int batch_size = x_tesor_batch.tensor_values_size();

        int64_t dims[dim_length];
        dims[0] = batch_size;
        for (int k = 1; k < dim_length; ++k) {
            dims[k] = x_tesor_batch.dims(k - 1);
        }

        torch::IntList dim_int_list = c10::ArrayRef<int64_t>(dims, dim_length);
        logDebug("dim_length：" + to_string(dim_length));

        int data_length = batch_size;
        for (int l = 0; l < dim_length - 1; ++l) {
            logDebug("dim_int_list index " + to_string(l) + "：" + to_string(dim_int_list[l]));
            data_length *= x_tesor_batch.dims(l);
        }

        tensorOptions = tensorOptionsDTypeSet(tensorOptions, x_tesor_batch.dtype());

        logDebug("sizes：" + to_string(data_length));
        void *data = tensorInit(x_tesor_batch.dtype(), data_length);

        int index = 0;

        for (int batch_index = 0; batch_index < batch_size; ++batch_index) {

            logDebug("batch_index：" + to_string(batch_index));

            TensorValue x_tensor = x_tesor_batch.tensor_values(batch_index);
            int count = x_tensor.items_size();

            //change the tensor value to pytorch tensor
            int one_tensor_dims[x_tesor_batch.dims_size()];

            logDebug("count：" + to_string(count));

            for (int i = 0; i < count; ++i) {
                tensorValueSet(data, index, x_tesor_batch.dtype(), x_tensor.items(i));
                index++;
            }
        }

        auto input_id = torch::from_blob(data, dim_int_list, tensorOptions);

        logDebug("ndimension：" + to_string(input_id.ndimension()));
        cout << "input tensor[" << x_name << "] value: " << input_id << std::endl;

        x_inputs.push_back(input_id);
    }

    logDebug("before forward");

    torch::Tensor outputs = ml_model->forward(x_inputs).toTensor();

    logDebug("after forward");

    cout << "outputs tensor: " << outputs << endl;

    torch::Tensor tensor = outputs;

    // 无需循环tensor
    // pytorch only one result
    string y_name = request->y_name(0);
    response->add_y_name(y_name);
    InnerTensor innerTensor = InnerTensor();
    innerTensor.set_tensor_name(y_name);

    for (int dim_index = 1; dim_index < outputs.dim(); ++dim_index) {
        innerTensor.add_dims(outputs.size(dim_index));
    }

    for (int batchIndsex = 0; batchIndsex < outputs.size(0); ++batchIndsex) {

        auto tensor_value = innerTensor.add_tensor_values();
        torch::Tensor tensor_one = outputs[batchIndsex];

        setOutputTensorValue(tensor_one, tensor_value);
    }

    response->mutable_output_tensor()->insert({y_name, innerTensor});
    return 0;
}

int unload(Model *model, ModelStatus *modelStatus) {
    return 0;
}
