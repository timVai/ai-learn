/**
  * pytorch_cache_model.h
  *
  * @author <a href=mailto:lizhipeng@jd.com>李志鹏</a>
  * @date 2019/01/07 16:31
  * @todo the model cache
  */
#include "pytorch_cache_models.h"

PytorchCacheModels::PytorchCacheModels() {}

PytorchCacheModels::~PytorchCacheModels() {
    map<string, torch::jit::script::Module*>::iterator it=IntMap.begin();
    vector<string> keys ;
    while(it != IntMap.end()){
        keys.push_back(it->first);
    }
    for (std::vector<string>::iterator keys_it = keys.begin() ; keys_it != keys.end(); ++keys_it) {
//        logInfo(" to delete the pytorch model for key [" + *keys_it +"]");
        delete IntMap[*keys_it];
    }
}
void PytorchCacheModels::add(string key, torch::jit::script::Module* value) {
    if ( IntMap.find(key) == IntMap.end() ) {
        IntMap[key]=std::move(value);
//        logInfo(" to add the pytorch model for key [" + key + "]");
    } else {
//        logInfo(" the key [" + key +"] of pytorch model already exist");
    }

}

torch::jit::script::Module* PytorchCacheModels::get(string key) {
    return IntMap[key];
}

void PytorchCacheModels::remove(string key) {
    IntMap.erase(key);
}