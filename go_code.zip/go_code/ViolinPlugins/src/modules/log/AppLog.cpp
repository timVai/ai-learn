/**
  * AppLog.cpp
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#include<iostream>

#include <log4cpp/PropertyConfigurator.hh>

#include "AppLog.h"

using namespace std;

AppLog *AppLog::_plog = NULL;

//获取log指针
AppLog &AppLog::getInstance(char *path) {

    if (_plog == NULL) {
        if (path == NULL) {
            string log_path = "../conf";
            cout << "log init path default " << log_path << endl;
            _plog = new AppLog(log_path);
        } else {
            cout << "log init path " << path << endl;
            _plog = new AppLog(path);
        }
    }

    return *_plog;
}

//销毁
void AppLog::destory() {
    if (_plog) {
        _plog->_category_root.info("AppLog destroy");
        _plog->_category_root.shutdown();
        delete _plog;
    }
}

//构造函数
AppLog::AppLog(string path) :
        _category_root(log4cpp::Category::getRoot()) {
    std::string initFileName = path + "/log4cpp.properties";
    log4cpp::PropertyConfigurator::configure(initFileName);
}

void AppLog::error(const char *msg) {
    _category_root.error(msg);
}

void AppLog::warn(const char *msg) {
    _category_root.warn(msg);
}

void AppLog::info(const char *msg) {
    _category_root.info(msg);
}

void AppLog::debug(const char *msg) {
    _category_root.debug(msg);
}
