/**
  * AppLog.h
  *
  * @author <a href=mailto:chendapeng@jd.com>陈大鹏</a>
  * @date 2018/12/5 16:31
  * @func
  */

#ifndef _APPLOG_H
#define _APPLOG_H

#include<iostream>
#include<cstdlib>

#include<log4cpp/Category.hh>

using namespace std;

//用单例模式封装log4cpp
class AppLog {

public:
    static AppLog &getInstance(char *path);

    static void destory();

    void error(const char *msg);

    void warn(const char *msg);

    void info(const char *msg);

    void debug(const char *msg);

private:
    AppLog(string path);  //单例模式：构造函数私有化

private:
    static AppLog *_plog;
    log4cpp::Category &_category_root;
};

//*****************************************************
//注意：
//文件名 __FILE__ ,函数名 __func__ ，行号__LINE__ 是编译器实现的
//并非C++头文件中定义的 
//前两个变量是string类型，且__LINE__是整形，所以需要转为string类型
//******************************************************

//整数类型文件行号 ->转换为string类型
inline std::string int2string(int line) {
    std::ostringstream oss;
    oss << line;
    return oss.str();
}

//定义一个在日志后添加 文件名 函数名 行号 的宏定义
#define suffix(msg)  std::string("").append("[")\
        .append(__PRETTY_FUNCTION__).append(":").append(__func__)\
        .append(":").append(int2string(__LINE__))\
        .append("] ").append(msg).c_str()

char *_violin_log_path = getenv("CPP_LOG_PATH");

//不用每次使用时写 getInstance语句
//只需要在主函数文件中写: #define _LOG4CPP_即可在整个程序中使用
AppLog &_violin_log = AppLog::getInstance(_violin_log_path);

//缩短并简化函数调用形式
#define logError(msg) _violin_log.error(suffix(msg))
#define logWarn(msg) _violin_log.warn(suffix(msg))
#define logInfo(msg) _violin_log.info(suffix(msg))
#define logDebug(msg) _violin_log.debug(suffix(msg))

#endif
