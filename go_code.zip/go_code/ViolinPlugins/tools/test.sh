#!/usr/bin/env bash

set -e

APP_HOME="$(cd $(dirname $0)/..; pwd -P)"

${APP_HOME}/bin/test1

