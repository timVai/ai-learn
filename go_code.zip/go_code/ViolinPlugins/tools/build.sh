#!/usr/bin/env bash

set -e

APP_HOME="$(cd $(dirname $0)/..; pwd -P)"

rm -rf ${APP_HOME}/build/*
rm -rf ${APP_HOME}/bin/*
rm -rf ${APP_HOME}/lib/*
rm -rf ${APP_HOME}/logs/*
mkdir -p ${APP_HOME}/build
cd ${APP_HOME}/build
cmake ..
make

