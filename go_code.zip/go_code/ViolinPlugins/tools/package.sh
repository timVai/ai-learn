#!/usr/bin/env bash

set -e

APP_HOME="$(cd $(dirname $0)/..; pwd -P)"
cd ${APP_HOME}/../
mkdir -p ${APP_HOME}/package

PROJECT_NAME="ViolinPlugins"
PACKAGE_FILE=${APP_HOME}/package/${PROJECT_NAME}.tar.gz

if [ -f ${PACKAGE_FILE} ]; then
    rm ${PACKAGE_FILE}
fi

tar -zcvf ${PACKAGE_FILE} ${PROJECT_NAME}/bin \
    ${PROJECT_NAME}/conf \
    ${PROJECT_NAME}/logs/.gitignore \
    ${PROJECT_NAME}/data \
    ${PROJECT_NAME}/lib \
    ${PROJECT_NAME}/tools/test.sh
