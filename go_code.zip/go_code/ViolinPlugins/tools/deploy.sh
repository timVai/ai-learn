#!/usr/bin/env bash

set -e

APP_HOME="$(cd $(dirname $0)/..; pwd -P)"
DEPLOY_HOME="/App/Violin"

mkdir -p ${DEPLOY_HOME}/lib
cp ${APP_HOME}/lib/lib* ${DEPLOY_HOME}/lib
mkdir -p /App/Violin/includes
cp ${APP_HOME}/src/modules/api/*.h ${DEPLOY_HOME}/includes

echo "deploy success"
